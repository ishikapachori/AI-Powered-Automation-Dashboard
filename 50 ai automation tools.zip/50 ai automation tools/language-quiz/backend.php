<?php
// backend.php - PHP backend for the Language Learning Quiz application

// CORS headers for development (you can adjust for production)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// If this is a preflight OPTIONS request, return early
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Please use POST.']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['text']) || empty(trim($data['text']))) {
    http_response_code(400);
    echo json_encode(['error' => 'No text provided.']);
    exit;
}

// Sanitize input
$text = trim($data['text']);
$sourceLanguage = isset($data['sourceLanguage']) ? trim($data['sourceLanguage']) : 'auto';
$targetLanguage = isset($data['targetLanguage']) ? trim($data['targetLanguage']) : 'en';

// Validate language codes
$validLanguages = ['auto', 'en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko'];
if (!in_array($sourceLanguage, $validLanguages) || !in_array($targetLanguage, $validLanguages)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid language selection.']);
    exit;
}

// Make sure source and target languages are different (unless source is auto)
if ($sourceLanguage !== 'auto' && $sourceLanguage === $targetLanguage) {
    http_response_code(400);
    echo json_encode(['error' => 'Source and target languages cannot be the same.']);
    exit;
}

// Ollama API configuration
$ollamaHost = 'http://localhost:11434'; // Default Ollama API address
$model = 'llama3';  // Change to the model you have available (llama3, llama3:8b, mistral, etc.)

// Prepare prompt for Ollama
$prompt = <<<EOT
I need a language learning vocabulary quiz based on the following text. 
Text: $text

Source language: $sourceLanguage
Target language: $targetLanguage

Create a vocabulary quiz with 5 multiple-choice questions (or fewer if the text is very short).
Each question should test understanding of a word or phrase from the text.
Each question should have 4 options with only 1 correct answer.

Format the response as a valid JSON object with the following structure:
{
    "questions": [
        {
            "question": "What is the meaning of '[word/phrase in source language]'?",
            "options": ["option1", "option2", "option3", "option4"],
            "correctIndex": 0
        },
        ...
    ]
}

The correctIndex should be the index (0-3) of the correct answer in the options array.
Don't include any explanations or additional text - just the JSON object.
EOT;

// Function to call Ollama API
function callOllamaAPI($host, $model, $prompt) {
    $url = "$host/api/generate";
    $data = [
        'model' => $model,
        'prompt' => $prompt,
        'stream' => false
    ];
    
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);
    
    if ($result === FALSE) {
        // Check for errors
        $error = error_get_last();
        return ["error" => "Failed to connect to Ollama API: " . $error['message']];
    }
    
    return json_decode($result, true);
}

try {
    // Call Ollama API
    $response = callOllamaAPI($ollamaHost, $model, $prompt);
    
    if (isset($response['error'])) {
        throw new Exception($response['error']);
    }
    
    // Extract the response text from Ollama
    $responseText = isset($response['response']) ? $response['response'] : '';
    
    if (empty($responseText)) {
        throw new Exception("Empty response from Ollama API");
    }
    
    // Extract the JSON object from the response
    // First, try to decode the entire response as JSON
    $decodedResponse = json_decode($responseText, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        // If the response is not valid JSON, try to extract JSON using regex
        if (preg_match('/\{.*\}/s', $responseText, $matches)) {
            $jsonStr = $matches[0];
            $decodedResponse = json_decode($jsonStr, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Invalid JSON format in response");
            }
        } else {
            throw new Exception("Could not extract valid JSON from response");
        }
    }
    
    // Validate the response structure
    if (!isset($decodedResponse['questions']) || !is_array($decodedResponse['questions'])) {
        throw new Exception("Invalid response format: missing questions array");
    }
    
    // Validate each question
    foreach ($decodedResponse['questions'] as $index => $question) {
        if (!isset($question['question']) || !isset($question['options']) || !isset($question['correctIndex'])) {
            throw new Exception("Question $index is missing required fields");
        }
        
        if (!is_array($question['options']) || count($question['options']) < 2) {
            throw new Exception("Question $index has insufficient options");
        }
        
        if (!is_numeric($question['correctIndex']) || $question['correctIndex'] < 0 || 
            $question['correctIndex'] >= count($question['options'])) {
            // Fix the correctIndex if it's out of bounds
            $question['correctIndex'] = 0;
        }
    }
    
    // Success - return the quiz questions
    echo json_encode($decodedResponse);
    
} catch (Exception $e) {
    // Handle errors
    http_response_code(500);
    echo json_encode([
        'error' => 'Error generating quiz: ' . $e->getMessage(),
        'fallback' => [
            'questions' => [
                [
                    'question' => 'The server encountered an error. This is a sample question.',
                    'options' => ['Option 1', 'Option 2', 'Option 3', 'Option 4'],
                    'correctIndex' => 0
                ]
            ]
        ]
    ]);
}
?>