<?php
header('Content-Type: application/json');
require_once 'vendor/autoload.php'; // Include Composer autoloader if using Ollama PHP client

// Database configuration (example using SQLite)
$db = new PDO('sqlite:reminders.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create tables if they don't exist
$db->exec("CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_name TEXT NOT NULL,
    deadline DATETIME NOT NULL,
    team_members TEXT NOT NULL,
    frequency INTEGER NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'scheduled',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Handle different actions
$action = $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'create':
            createReminder();
            break;
        case 'list':
            listReminders();
            break;
        case 'cancel':
            cancelReminder();
            break;
        case 'ai_enhance':
            enhanceWithAI();
            break;
        default:
            echo json_encode(['error' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

function createReminder() {
    global $db;
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $stmt = $db->prepare("INSERT INTO reminders 
        (task_name, deadline, team_members, frequency, message) 
        VALUES (?, ?, ?, ?, ?)");
    
    $stmt->execute([
        $data['taskName'],
        $data['deadline'],
        $data['teamMembers'],
        $data['frequency'],
        $data['message']
    ]);
    
    $id = $db->lastInsertId();
    
    // In a real app, you would set up actual email scheduling here
    echo json_encode([
        'success' => true,
        'id' => $id,
        'message' => 'Reminder scheduled successfully'
    ]);
}

function listReminders() {
    global $db;
    
    $stmt = $db->query("SELECT * FROM reminders ORDER BY deadline ASC");
    $reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $reminders
    ]);
}

function cancelReminder() {
    global $db;
    
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'];
    
    $stmt = $db->prepare("UPDATE reminders SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Reminder cancelled'
    ]);
}

function enhanceWithAI() {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $taskName = $data['taskName'];
    $deadline = $data['deadline'];
    $frequency = $data['frequency'];
    $customMessage = $data['customMessage'] ?? '';
    
    // In a real implementation, you would call your Ollama/Llama3 API here
    // This is a simulation of what the response might look like
    
    $enhancedMessage = "🚀 Important Deadline Reminder: \"$taskName\"\n\n";
    $enhancedMessage .= "This is a friendly reminder that this task is due on " . date('F j, Y', strtotime($deadline)) . ".\n\n";
    
    if ($frequency > 0) {
        $enhancedMessage .= "You're receiving this reminder " . $frequency . " day(s) in advance to ensure ample time for completion.\n\n";
    } else {
        $enhancedMessage .= "This is your final reminder as the deadline is today!\n\n";
    }
    
    if (!empty($customMessage)) {
        $enhancedMessage .= "Additional notes: $customMessage\n\n";
    } else {
        $enhancedMessage .= "Please prioritize this task and reach out if you need any support.\n\n";
    }
    
    $enhancedMessage .= "Best regards,\nYour Team";
    
    echo json_encode([
        'success' => true,
        'enhancedMessage' => $enhancedMessage
    ]);
}
?>