function generateResponse() {
  const request = document.getElementById('request').value.trim();
  const action = document.getElementById('action').value;
  const output = document.getElementById('output');

  if (!request) {
    output.innerText = "Please paste a leave request.";
    return;
  }

  output.innerText = "Generating response...";

  fetch('generate.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ request, action })
  })
  .then(res => res.text())
  .then(data => output.innerText = data)
  .catch(err => output.innerText = "Error: " + err.message);
}
