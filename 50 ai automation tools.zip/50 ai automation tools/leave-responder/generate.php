<?php
set_time_limit(300);

$data = json_decode(file_get_contents("php://input"), true);
$request = $data['request'] ?? '';
$action = $data['action'] ?? 'accept';

if (!$request) {
  echo "No leave request provided.";
  exit;
}

$actionText = $action === 'accept' ? "approve" : "reject";

$prompt = "You are an HR manager. Write a formal email to {$actionText} the following leave request. Be polite and professional. Here is the request:\n\n\"$request\"\n\nKeep your reply concise and use a proper business tone.";

$payload = json_encode([
  "model" => "llama3",
  "prompt" => $prompt,
  "stream" => false
]);

$ch = curl_init("http://localhost:11434/api/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
echo $result['response'] ?? "No response from AI.";
