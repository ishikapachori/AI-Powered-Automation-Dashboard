<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["question"])) {
    $question = $_POST["question"];

    $prompt = "You are a decision support assistant. The user asked:\n\n\"$question\"\n\nProvide a pros and cons list with brief reasoning.";

    $data = [
        "model" => "llama3",
        "prompt" => $prompt,
        "stream" => false
    ];

    $ch = curl_init("http://localhost:11434/api/generate");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json"
    ]);

    $result = curl_exec($ch);
    curl_close($ch);

    if ($result) {
        $json = json_decode($result, true);
        echo $json["response"];
    } else {
        echo "Failed to connect to Ollama.";
    }
} else {
    echo "No question received.";
}
?>
