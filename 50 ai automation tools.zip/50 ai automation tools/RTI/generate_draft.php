<?php
header('Content-Type: application/json');

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (empty($data['documentType']) || empty($data['requestDetails']) || empty($data['tone'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

// Prepare the prompt for LLaMA3/Ollama
$prompt = "Generate a {$data['documentType']} with a {$data['tone']} tone based on the following request details:\n\n";
$prompt .= "Request Details: {$data['requestDetails']}\n\n";
if (!empty($data['additionalInfo'])) {
    $prompt .= "Additional Information: {$data['additionalInfo']}\n\n";
}
$prompt .= "Please format the response as a properly structured official document with appropriate headings, salutations, and closing. Ensure the language is professional and suitable for government correspondence.";

// Call Ollama API (adjust the endpoint as needed)
$ollamaResponse = callOllamaAPI($prompt);

if ($ollamaResponse) {
    echo json_encode(['success' => true, 'draft' => $ollamaResponse]);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to generate draft']);
}

function callOllamaAPI($prompt) {
    // Ollama API endpoint (adjust as needed)
    $url = 'http://localhost:11434/api/generate';
    
    // Prepare the data for Ollama
    $ollamaData = [
        'model' => 'llama3', // or any other model you're using
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 2000
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ollamaData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute and get response
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        error_log('Ollama API Error: ' . curl_error($ch));
        return false;
    }
    
    curl_close($ch);
    
    // Parse the response (Ollama returns a stream of responses, we need to combine them)
    $responseLines = explode("\n", $response);
    $fullResponse = '';
    
    foreach ($responseLines as $line) {
        if (!empty(trim($line))) {
            $json = json_decode($line, true);
            if (isset($json['response'])) {
                $fullResponse .= $json['response'];
            }
        }
    }
    
    return $fullResponse ?: false;
}
?>