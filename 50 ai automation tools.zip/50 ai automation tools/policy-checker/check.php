<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $_POST['question'];
    $policy = file_get_contents('policy.txt');

    $data = [
        "model" => "llama3",
        "messages" => [
            ["role" => "system", "content" => "You are an assistant that answers questions based strictly on company policy."],
            ["role" => "user", "content" => "Refer to the following company policy:\n\n" . $policy . "\n\nNow answer this question:\n" . $question]
        ]
    ];

    $ch = curl_init('http://localhost:11434/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
    echo $result['choices'][0]['message']['content'];
}
?>
