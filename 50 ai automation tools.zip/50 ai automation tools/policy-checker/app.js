document.getElementById('policyForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const question = document.getElementById('question').value;
    const response = await fetch('check.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'question=' + encodeURIComponent(question)
    });
    const result = await response.text();
    document.getElementById('output').textContent = result;
});
