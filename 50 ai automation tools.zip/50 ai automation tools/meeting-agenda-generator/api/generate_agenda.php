<?php
header('Content-Type: application/json');

// Enable CORS if needed
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['title']) || !isset($input['purpose'])) {
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Extract data
$title = trim($input['title']);
$purpose = trim($input['purpose']);
$keywords = isset($input['keywords']) ? trim($input['keywords']) : '';
$duration = isset($input['duration']) ? intval($input['duration']) : 60;
$tone = isset($input['tone']) ? trim($input['tone']) : 'professional';

// Prepare the prompt for LLaMA3
$prompt = "Generate a professional meeting agenda based on the following details:\n\n";
$prompt .= "Meeting Title: $title\n";
$prompt .= "Meeting Purpose: $purpose\n";
if (!empty($keywords)) {
    $prompt .= "Key Topics: $keywords\n";
}
$prompt .= "Duration: $duration minutes\n";
$prompt .= "Tone: $tone\n\n";
$prompt .= "The agenda should include:\n";
$prompt .= "- A header with the meeting title, date (use today's date), time (use current time), and location (virtual if not specified)\n";
$prompt .= "- Clear objectives at the top\n";
$prompt .= "- A well-structured timeline with time allocations for each agenda item\n";
$prompt .= "- Topics in logical order with responsible persons (use 'Facilitator' if not specified)\n";
$prompt .= "- Time for Q&A if appropriate\n";
$prompt .= "- Next steps/action items at the end\n";
$prompt .= "Format the agenda professionally with clear sections and proper spacing.";

// Call Ollama's LLaMA3 API
$ollamaResponse = callOllamaLLaMA3($prompt);

if ($ollamaResponse === false) {
    echo json_encode(['error' => 'Failed to generate agenda. Please try again.']);
    exit;
}

// Return the generated agenda
echo json_encode(['agenda' => $ollamaResponse]);

function callOllamaLLaMA3($prompt) {
    // Ollama API endpoint (adjust according to your setup)
    $ollamaUrl = 'http://localhost:11434/api/generate'; // Default Ollama URL
    
    // Prepare the data for Ollama
    $data = [
        'model' => 'llama3', // or whatever model you're using
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 2000
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($ollamaUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute the request
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        error_log('Ollama API error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }
    
    curl_close($ch);
    
    // Parse the response
    $responseData = json_decode($response, true);
    
    if (isset($responseData['response'])) {
        return trim($responseData['response']);
    }
    
    return false;
}
?>