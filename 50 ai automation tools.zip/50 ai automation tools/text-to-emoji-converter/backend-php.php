<?php
// backend.php - Process text and add contextual emojis using the Ollama API

// Allow cross-origin requests (if frontend and backend are on different servers)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the request body
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['text']) || empty($input['text'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Text is required']);
    exit;
}

if (!isset($input['model']) || empty($input['model'])) {
    $input['model'] = 'llama3'; // Default model
}

$text = trim($input['text']);
$model = trim($input['model']);

// Map frontend model selection to Ollama model names
$modelMap = [
    'llama3' => 'llama3',
    'mistral' => 'mistral',
    'gemma' => 'gemma:2b',
    'phi3' => 'phi3:mini'
];

// Use the mapped model or default to llama3 if not found
$ollamaModel = isset($modelMap[$model]) ? $modelMap[$model] : 'llama3';

// Call the Ollama API to generate emojis
function callOllamaAPI($text, $model) {
    // Ollama API endpoint (assuming Ollama is running locally)
    $url = 'http://localhost:11434/api/generate';
    
    $prompt = <<<EOT
You are an emoji assistant that adds contextually relevant emojis to text.
Given the following text, add appropriate emojis based on the context, tone, and keywords:

Text: $text

Rules:
1. Only add emojis - DO NOT modify the original text
2. Place emojis at the end of sentences or at the end of the text
3. Choose emojis that match the emotional tone and specific topics mentioned
4. Use 1-3 emojis maximum
5. Return ONLY the original text with added emojis - no explanations

Output:
EOT;

    $data = [
        'model' => $model,
        'prompt' => $prompt,
        'stream' => false,
        'temperature' => 0.7
    ];

    // Initialize cURL session
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    // Execute the request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['success' => false, 'error' => $error];
    }
    
    // Close the cURL session
    curl_close($ch);
    
    // Parse the response
    $responseData = json_decode($response, true);
    
    if (isset($responseData['response'])) {
        return ['success' => true, 'result' => trim($responseData['response'])];
    } else {
        return ['success' => false, 'error' => 'Invalid response from Ollama API'];
    }
}

// Fallback function if Ollama API is unavailable
function addEmojisLocally($text) {
    // Simple keyword to emoji mappings
    $emojiMappings = [
        'happy' => ['😊', '😃', '😄'],
        'sad' => ['😢', '😔', '😞'],
        'angry' => ['😠', '😡', '👿'],
        'love' => ['❤️', '💕', '😍'],
        'beach' => ['🏖️', '🌊', '😎'],
        'food' => ['🍔', '🍕', '🍽️'],
        'work' => ['💼', '💻', '📱'],
        'sleep' => ['😴', '💤', '🛌'],
        'party' => ['🎉', '🎊', '🥳'],
        'travel' => ['✈️', '🧳', '🗺️'],
        'music' => ['🎵', '🎶', '🎸'],
        'school' => ['📚', '📝', '🎓'],
        'weather' => ['☀️', '🌧️', '⛈️'],
        'sports' => ['⚽', '🏀', '🏈'],
        'holiday' => ['🎄', '🎃', '🎁']
    ];
    
    $addedEmojis = [];
    $textLower = strtolower($text);
    
    // Check for keyword matches
    foreach ($emojiMappings as $keyword => $emojis) {
        if (strpos($textLower, $keyword) !== false) {
            // Randomly select one emoji from the array
            $emoji = $emojis[array_rand($emojis)];
            $addedEmojis[] = $emoji;
            
            // Limit to 3 emojis maximum
            if (count($addedEmojis) >= 3) {
                break;
            }
        }
    }
    
    // If no emoji was added, add a generic one
    if (empty($addedEmojis)) {
        $addedEmojis[] = '👍';
    }
    
    // Add emojis to the end of the text
    return $text . ' ' . implode('', $addedEmojis);
}

try {
    // Try using Ollama API first
    $result = callOllamaAPI($text, $ollamaModel);
    
    // If Ollama API call failed, use local fallback
    if (!$result['success']) {
        $processedText = addEmojisLocally($text);
        echo json_encode(['success' => true, 'result' => $processedText]);
    } else {
        echo json_encode(['success' => true, 'result' => $result['result']]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?>