<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get the POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (empty($data['input'])) {
    echo json_encode(['error' => 'Input text or topic is required']);
    exit;
}

// Prepare the prompt for LLaMA3
$prompt = buildPrompt($data);

// Call Ollama API (assuming it's running locally)
$ollamaResponse = callOllamaAPI($prompt);

// Process the response
if ($ollamaResponse === false) {
    echo json_encode(['error' => 'Failed to generate questions']);
    exit;
}

// Parse the response into structured questions
$questions = parseOllamaResponse($ollamaResponse, $data['type']);

// Return the questions
echo json_encode(['questions' => $questions]);

// Helper functions
function buildPrompt($data) {
    $input = $data['input'];
    $type = $data['type'];
    $difficulty = $data['difficulty'];
    $isTopic = $data['isTopic'];
    
    $prompt = "Generate assessment questions based on the following ";
    $prompt .= $isTopic ? "topic: '$input'" : "paragraph: '$input'";
    $prompt .= "\n\nDifficulty level: $difficulty";
    $prompt .= "\n\nGenerate ";
    
    switch ($type) {
        case 'mcq':
            $prompt .= "5 multiple choice questions with 4 options each and indicate the correct answer.";
            break;
        case 'short':
            $prompt .= "5 short answer questions with brief answers.";
            break;
        case 'comprehension':
            $prompt .= "a comprehension passage with 5 questions (mix of short answer and multiple choice).";
            break;
        case 'mixed':
            $prompt .= "a mix of 3 multiple choice, 3 short answer, and 2 comprehension questions.";
            break;
        default:
            $prompt .= "5 questions of various types.";
    }
    
    $prompt .= "\n\nFormat your response as a JSON array where each question has: ";
    $prompt .= "question (string), type (mcq|short|comprehension), ";
    $prompt .= "options (array for mcq), answer (string).";
    
    return $prompt;
}

function callOllamaAPI($prompt) {
    $url = 'http://localhost:11434/api/generate'; // Ollama's default API endpoint
    
    $data = [
        'model' => 'llama3', // or your preferred model
        'prompt' => $prompt,
        'format' => 'json',
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 2000
        ]
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

function parseOllamaResponse($response, $expectedType) {
    $data = json_decode($response, true);
    
    if (empty($data['response'])) {
        return [];
    }
    
    // Try to parse the JSON response from Ollama
    $parsed = json_decode($data['response'], true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        // If not valid JSON, try to extract questions from text
        return extractQuestionsFromText($data['response'], $expectedType);
    }
    
    return $parsed;
}

function extractQuestionsFromText($text, $expectedType) {
    // This is a fallback when Ollama doesn't return proper JSON
    // It attempts to extract questions from plain text response
    $questions = [];
    $lines = explode("\n", $text);
    
    $currentQuestion = null;
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        if (empty($line)) continue;
        
        // Detect question
        if (preg_match('/^\d+\.\s*(.+)/', $line, $matches)) {
            if ($currentQuestion) {
                $questions[] = $currentQuestion;
            }
            $currentQuestion = [
                'question' => $matches[1],
                'type' => $expectedType === 'mcq' ? 'mcq' : 'short',
                'answer' => ''
            ];
        }
        // Detect options for MCQ
        elseif ($currentQuestion && $expectedType === 'mcq' && preg_match('/^[a-d]\.\s*(.+)/i', $line, $matches)) {
            if (!isset($currentQuestion['options'])) {
                $currentQuestion['options'] = [];
            }
            $currentQuestion['options'][] = $matches[1];
        }
        // Detect answer
        elseif ($currentQuestion && preg_match('/^(answer:|correct:)\s*(.+)/i', $line, $matches)) {
            $currentQuestion['answer'] = $matches[2];
        }
    }
    
    if ($currentQuestion) {
        $questions[] = $currentQuestion;
    }
    
    return $questions;
}
?>