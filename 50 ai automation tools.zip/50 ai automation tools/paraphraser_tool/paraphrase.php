<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = $_POST['text'] ?? '';
    $style = $_POST['style'] ?? 'simple';

    $prompt = "Paraphrase the following text in a {$style} style:\n\n" . $text;

    $ch = curl_init('http://localhost:11434/api/generate');
    $data = json_encode([
        "model" => "llama3",
        "prompt" => $prompt,
        "stream" => false
    ]);

    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error: " . curl_error($ch);
        exit;
    }

    curl_close($ch);

    $result = json_decode($response, true);
    echo $result['response'] ?? 'Error processing the response.';
} else {
    echo "Invalid request.";
}
