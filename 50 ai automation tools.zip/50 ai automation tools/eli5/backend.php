<?php
// Get the question SAFELY
$data = json_decode(file_get_contents('php://input'), true);
$question = $data['question'] ?? "No question asked"; // <- Safety check!

// Talk to AI (with extra safety)
if ($question !== "No question asked") {
    $ch = curl_init('http://localhost:11434/api/generate');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode([
            'model' => 'llama3',
            'prompt' => $question,
            'stream' => false
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    
    $response = curl_exec($ch);
    echo $response ? json_decode($response)->response : "AI is sleeping";
    curl_close($ch);
} else {
    echo "Please ask a question!";
}
?>