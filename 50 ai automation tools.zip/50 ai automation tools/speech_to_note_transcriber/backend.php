<?php
header('Content-Type: application/json');

// Check if the request has the required action
if (!isset($_POST['action'])) {
    echo json_encode(['success' => false, 'error' => 'No action specified']);
    exit;
}

$action = $_POST['action'];

try {
    if ($action === 'transcribe') {
        // Handle audio transcription
        if (!isset($_FILES['audio'])) {
            throw new Exception('No audio file uploaded');
        }

        $audioFile = $_FILES['audio'];
        $tempPath = $audioFile['tmp_name'];
        $targetPath = 'uploads/' . uniqid() . '.wav';

        // Create uploads directory if it doesn't exist
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        // Move the uploaded file
        if (!move_uploaded_file($tempPath, $targetPath)) {
            throw new Exception('Failed to move uploaded file');
        }

        // Transcribe using Whisper via Ollama API
        $transcription = transcribeWithWhisper($targetPath);

        // Clean up - delete the audio file
        unlink($targetPath);

        echo json_encode([
            'success' => true,
            'transcription' => $transcription
        ]);

    } elseif ($action === 'summarize') {
        // Handle text summarization
        if (!isset($_POST['text'])) {
            throw new Exception('No text provided for summarization');
        }

        $text = $_POST['text'];
        $summary = summarizeWithLLM($text);

        echo json_encode([
            'success' => true,
            'summary' => $summary
        ]);

    } else {
        throw new Exception('Invalid action');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
function transcribeWithWhisper($audioPath) {
    $command = escapeshellcmd("python3 transcribe.py " . escapeshellarg($audioPath));
    $output = shell_exec($command);
    return $output ?: 'Transcription failed';
}

function summarizeWithLLM($text) {
    $url = 'http://localhost:11434/api/generate';
    
    $prompt = "Please summarize the following meeting transcript into concise bullet points highlighting key decisions and action items:\n\n" . $text;
    
    $data = [
        'model' => 'llama3', // or 'mistral' or other model you have
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.3
        ]
    ];
    
    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
        ],
    ];
    
    $context  = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    
    if ($response === FALSE) {
        throw new Exception('Failed to call LLM API');
    }
    
    $json = json_decode($response, true);
    return $json['response'] ?? 'No summary generated';
}
?>