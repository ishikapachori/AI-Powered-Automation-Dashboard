<?php
// backend.php

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$headline = trim($data["headline"] ?? '');

if (!$headline) {
    echo json_encode(["rewrite" => "No headline provided."]);
    exit;
}

// Prompt to send to LLaMA3
$prompt = "Rewrite the following news headline in a more engaging, funny, clickbait, or educational tone. Only return the rewritten headline.\n\nOriginal: \"$headline\"\n\nRewritten:";

$payload = json_encode([
    "model" => "llama3",
    "prompt" => $prompt,
    "stream" => true
]);

$ch = curl_init("http://localhost:11434/api/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);

$response = curl_exec($ch);
curl_close($ch);

// Ollama returns streaming chunks
$lines = explode("\n", $response);
$final = "";

foreach ($lines as $line) {
    if ($line) {
        $json = json_decode($line, true);
        if (isset($json["response"])) {
            $final .= $json["response"];
        }
    }
}

echo json_encode(["rewrite" => trim($final)]);
