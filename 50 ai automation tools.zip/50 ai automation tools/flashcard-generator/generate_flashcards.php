<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$input = $_POST['topic'] ?? '';
if (!$input) {
    echo json_encode(["error" => "No input provided"]);
    exit;
}

$prompt = "Turn the following topic into 5 flashcards in Q&A format:\nTopic: $input\nFormat:\nQ: Question\nA: Answer\n---";

$data = [
    "model" => "llama3",
    "prompt" => $prompt,
    "stream" => false
];

$ch = curl_init("http://localhost:11434/api/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error || !$response || $httpcode !== 200) {
    echo json_encode(["error" => "Call to Ollama failed", "curl_error" => $error, "http_code" => $httpcode, "raw_response" => $response]);
    exit;
}

$result = json_decode($response, true);
$raw = $result['response'] ?? '';

$cards = [];
preg_match_all("/Q:\s*(.*?)\nA:\s*(.*?)(?:\n|$)/s", $raw, $matches, PREG_SET_ORDER);
foreach ($matches as $m) {
    $cards[] = ["question" => trim($m[1]), "answer" => trim($m[2])];
}

echo json_encode($cards);
