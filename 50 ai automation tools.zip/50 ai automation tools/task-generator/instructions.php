<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $brief = $_POST['brief'] ?? '';

    if (empty($brief)) {
        echo "Please enter a brief task description.";
        exit;
    }

    $prompt = "You are a project manager. Based on the following brief, generate clear and detailed step-by-step instructions suitable for a team to follow:\n\n";
    $prompt .= "Brief:\n" . $brief . "\n\n";
    $prompt .= "Make sure the instructions are actionable, organized, and easy to follow.";

    $data = [
        "model" => "llama3",
        "prompt" => $prompt,
        "stream" => false
    ];

    $ch = curl_init("http://localhost:11434/api/generate");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $decoded = json_decode($response, true);
    echo nl2br(htmlspecialchars($decoded['response'] ?? 'AI did not return any output.'));
}
?>
