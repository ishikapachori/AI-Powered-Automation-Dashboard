<?php
// process_meeting.php

header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate input
if (!isset($data['rawNotes']) || empty(trim($data['rawNotes']))) {
    echo json_encode(['error' => 'No meeting notes provided']);
    exit;
}

// Extract parameters with defaults
$rawNotes = trim($data['rawNotes']);
$formatStyle = $data['formatStyle'] ?? 'formal';
$detailLevel = $data['detailLevel'] ?? 'detailed';

// Prepare the prompt for Ollama
$prompt = createPrompt($rawNotes, $formatStyle, $detailLevel);

// Call Ollama API (adjust the model name as needed)
$ollamaResponse = callOllama($prompt);

// Process the response
if ($ollamaResponse === false) {
    echo json_encode(['error' => 'Failed to generate minutes']);
    exit;
}

// Return the polished minutes
echo json_encode(['minutes' => $ollamaResponse]);

/**
 * Creates a detailed prompt for Ollama based on user inputs
 */
function createPrompt($rawNotes, $formatStyle, $detailLevel) {
    $styleInstructions = [
        'formal' => "Write in a formal business tone, using complete sentences and proper grammar.",
        'informal' => "Write in a more casual, conversational tone while maintaining professionalism.",
        'bullet' => "Present the information in clear bullet points.",
        'paragraph' => "Write in paragraph format with smooth transitions between topics."
    ];
    
    $detailInstructions = [
        'detailed' => "Include all important details, discussions, decisions, and action items.",
        'concise' => "Be concise while covering key points, decisions, and action items.",
        'summary' => "Provide a high-level executive summary focusing on key decisions and action items."
    ];
    
    $prompt = "Convert the following raw meeting notes into polished meeting minutes.\n\n";
    $prompt .= "Style: " . $styleInstructions[$formatStyle] . "\n";
    $prompt .= "Detail Level: " . $detailInstructions[$detailLevel] . "\n\n";
    $prompt .= "Follow this structure:\n";
    $prompt .= "1. Meeting Title (create based on content)\n";
    $prompt .= "2. Date and Time (extract or use 'Date not specified')\n";
    $prompt .= "3. Attendees (list if mentioned)\n";
    $prompt .= "4. Agenda Items/Discussion Topics\n";
    $prompt .= "5. Key Decisions\n";
    $prompt .= "6. Action Items (with owners and deadlines if available)\n";
    $prompt .= "7. Next Meeting (if mentioned)\n\n";
    $prompt .= "Raw Notes:\n" . $rawNotes . "\n\n";
    $prompt .= "Polished Minutes:";
    
    return $prompt;
}

/**
 * Calls the Ollama API to generate the minutes
 */
function callOllama($prompt) {
    $model = 'llama3'; // Change to your preferred model
    
    $data = [
        'model' => $model,
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 2000
        ]
    ];
    
    $ch = curl_init('http://localhost:11434/api/generate');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        error_log('Ollama API error: ' . curl_error($ch));
        return false;
    }
    
    curl_close($ch);
    
    $responseData = json_decode($response, true);
    
    if (!isset($responseData['response'])) {
        error_log('Ollama API unexpected response: ' . $response);
        return false;
    }
    
    return trim($responseData['response']);
}
?>