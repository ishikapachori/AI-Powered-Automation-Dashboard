<?php
// analyze.php - Backend for CV Analyzer

header('Content-Type: application/json');

// Check if file was uploaded
if (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['error' => 'No file uploaded or upload error']);
    exit;
}

// Validate file type
$allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
];

if (!in_array($_FILES['resume']['type'], $allowedTypes)) {
    echo json_encode(['error' => 'Invalid file type. Only PDF, DOC, DOCX, or TXT allowed.']);
    exit;
}

// Check file size (5MB max)
if ($_FILES['resume']['size'] > 5 * 1024 * 1024) {
    echo json_encode(['error' => 'File size too large. Maximum 5MB allowed.']);
    exit;
}

// Extract text from the resume (simplified - in production you'd use a proper library)
$resumeText = '';
$tempFile = $_FILES['resume']['tmp_name'];

if ($_FILES['resume']['type'] === 'text/plain') {
    $resumeText = file_get_contents($tempFile);
} else {
    // For PDF/DOC/DOCX you would use a library like pdftotext or phpword
    // This is a simplified version that just returns placeholder text
    $resumeText = "This is a placeholder for the extracted text from the resume. " . 
                  "In a real implementation, you would use proper text extraction libraries. " . 
                  "The actual resume content would be processed here.";
}

// Get other form data
$jobTitle = $_POST['jobTitle'] ?? '';
$jobDescription = $_POST['jobDescription'] ?? '';
$analysisType = $_POST['analysisType'] ?? 'general';

// Prepare the prompt for Ollama/LLaMA3
$prompt = "Analyze this resume for a $jobTitle position. ";
$prompt .= "Here's the resume content:\n\n$resumeText\n\n";

if (!empty($jobDescription)) {
    $prompt .= "Here's the job description to compare against:\n\n$jobDescription\n\n";
}

switch ($analysisType) {
    case 'technical':
        $prompt .= "Provide a technical skills evaluation. List the technical skills found, " . 
                  "rate them from 1-5 based on proficiency indicators, and identify any gaps " . 
                  "for the target position. Format as a detailed technical assessment.";
        break;
    case 'ats':
        $prompt .= "Analyze this resume for ATS (Applicant Tracking System) compatibility. " . 
                  "Check for proper formatting, keyword optimization, section organization, " . 
                  "and provide specific recommendations to improve ATS scoring.";
        break;
    case 'detailed':
        $prompt .= "Provide a comprehensive analysis including: 1) Overall summary, " . 
                  "2) Strengths, 3) Areas for improvement, 4) Keyword matching with the job description, " . 
                  "5) Specific suggestions for enhancement, 6) Estimated ATS score if applicable.";
        break;
    default:
        $prompt .= "Provide general feedback on this resume. Highlight the main strengths, " . 
                  "identify areas for improvement, and give overall suggestions to make the " . 
                  "resume more effective for the target position.";
}

// Call Ollama API (this is a mock implementation)
function callOllama($prompt) {
    // In a real implementation, you would call your Ollama/LLaMA3 endpoint
    // This is a mock response that simulates what the AI might return
    
    // Simulate processing delay
    sleep(2);
    
    // Generate a mock analysis
    $score = rand(60, 90); // Random score between 60-90 for demo
    
    $strengths = [
        "Strong experience in relevant technologies",
        "Clear career progression demonstrated",
        "Good quantifiable achievements in previous roles",
        "Professional and well-organized format"
    ];
    
    $improvements = [
        "Could include more metrics to quantify achievements",
        "Some job descriptions could be more detailed",
        "Consider adding a skills section for quick scanning",
        "Could better highlight leadership experience"
    ];
    
    $keywords = [
        'matchPercentage' => rand(60, 95),
        'matched' => ['JavaScript', 'React', 'Team Leadership', 'Agile'],
        'missing' => ['TypeScript', 'AWS', 'CI/CD']
    ];
    
    $suggestions = "Consider restructuring your work experience to focus more on achievements rather than responsibilities. " . 
                  "Add metrics wherever possible (e.g., 'Increased performance by 30%'). " . 
                  "Include a technical skills section for quick scanning by recruiters. " . 
                  "Tailor your summary to more closely match the target job description.";
    
    $summary = "This is a strong resume with good experience in relevant areas. " . 
              "The candidate demonstrates progressive responsibility and has good technical skills. " . 
              "With some refinements to highlight achievements and better match the job description keywords, " . 
              "this resume could be even more effective.";
    
    return [
        'score' => $score,
        'summary' => $summary,
        'strengths' => $strengths,
        'improvements' => $improvements,
        'keywords' => $keywords,
        'suggestions' => $suggestions
    ];
}

// Get analysis from Ollama
$analysis = callOllama($prompt);

// Return the analysis as JSON
echo json_encode($analysis);
?>