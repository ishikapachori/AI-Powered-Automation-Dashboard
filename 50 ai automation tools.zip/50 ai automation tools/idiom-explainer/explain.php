<?php
// explain.php - Backend for Proverb & Idiom Explainer

// Allow cross-origin requests (if needed)
header('Content-Type: application/json');

// Get the input data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['idiom']) || empty($data['idiom'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No idiom provided']);
    exit;
}

$idiom = $data['idiom'];

// Create a class to handle Ollama API interactions
class OllamaChat {
    private $url;
    private $model;
    
    public function __construct($model = 'llama3', $url = 'http://localhost:11434') {
        $this->url = $url;
        $this->model = $model;
    }
    
    public function generateResponse($prompt) {
        $endpoint = $this->url . '/api/generate';
        
        $data = [
            'model' => $this->model,
            'prompt' => $prompt,
            'stream' => false
        ];
        
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json',
                'content' => json_encode($data)
            ]
        ];
        
        $context = stream_context_create($options);
        $result = file_get_contents($endpoint, false, $context);
        
        if ($result === FALSE) {
            throw new Exception('Error communicating with Ollama API');
        }
        
        $response = json_decode($result, true);
        return $response['response'] ?? '';
    }
}

try {
    // Create the Ollama client
    $ollama = new OllamaChat('llama3');
    
    // Craft a prompt that will get good results for idiom explanation
    $prompt = <<<EOT
Please explain the following idiom or proverb: "{$idiom}"

Provide your response in the following format:
1. Meaning: Provide a clear explanation of what this idiom or proverb means.
2. Example: Give an example sentence or situation where this idiom or proverb would be used appropriately.

If this is not a recognized idiom or proverb, please indicate that and try to provide the closest match or interpretation.
EOT;

    // Get response from Ollama
    $response = $ollama->generateResponse($prompt);
    
    // Parse the response to extract meaning and example
    $meaning = '';
    $example = '';
    
    if (preg_match('/Meaning:(.*?)(?=Example:|$)/s', $response, $meaningMatch)) {
        $meaning = trim($meaningMatch[1]);
    }
    
    if (preg_match('/Example:(.*?)$/s', $response, $exampleMatch)) {
        $example = trim($exampleMatch[1]);
    }
    
    // If parsing failed, provide the full response as meaning
    if (empty($meaning) && empty($example)) {
        $meaning = $response;
    }
    
    // Return the structured response
    echo json_encode([
        'meaning' => $meaning,
        'example' => $example
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
