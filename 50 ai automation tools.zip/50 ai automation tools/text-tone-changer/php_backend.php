<?php
header('Content-Type: application/json');

// Allow CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request method'
    ]);
    exit;
}

// Get the request body
$requestBody = file_get_contents('php://input');
$data = json_decode($requestBody, true);

// Validate input
if (!isset($data['text']) || !isset($data['tone'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Missing required parameters'
    ]);
    exit;
}

$text = $data['text'];
$tone = $data['tone'];

// Call the function to convert text tone
try {
    $convertedText = convertTextTone($text, $tone);
    
    echo json_encode([
        'success' => true,
        'convertedText' => $convertedText
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

/**
 * Convert text to specified tone using Ollama's LLaMA3 model
 * 
 * @param string $text The input text
 * @param string $tone The desired tone
 * @return string The converted text
 */
function convertTextTone($text, $tone) {
    // Ollama API endpoint (assuming Ollama is running locally)
    $ollamaEndpoint = 'http://localhost:11434/api/generate';
    
    // Prepare the prompt for the LLaMA3 model
    $prompt = "Convert the following text to a {$tone} tone while preserving its meaning:\n\n{$text}\n\nConverted text:";
    
    // Prepare the request data
    $requestData = [
        'model' => 'llama3',  // Use the LLaMA3 model
        'prompt' => $prompt,
        'stream' => false
    ];
    
    // Initialize cURL session
    $ch = curl_init($ollamaEndpoint);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check for cURL errors
    if (curl_errno($ch)) {
        throw new Exception('cURL error: ' . curl_error($ch));
    }
    
    // Close cURL session
    curl_close($ch);
    
    // Decode the response
    $responseData = json_decode($response, true);
    
    // Check if the response contains the expected data
    if (!isset($responseData['response'])) {
        throw new Exception('Invalid response from Ollama API');
    }
    
    // Extract and clean the converted text
    $convertedText = trim($responseData['response']);
    
    return $convertedText;
}
?>
