<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get the JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input
if (empty($data['jobRole']) || empty($data['experienceLevel']) || empty($data['questionType'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Prepare the prompt for Ollama/LLaMA3
$prompt = generatePrompt($data);

// Call Ollama API
$response = callOllama($prompt);

// Process the response
if ($response === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate questions']);
    exit;
}

// Parse the response based on question type
$result = parseResponse($response, $data['questionType']);

echo json_encode($result);

function generatePrompt($data) {
    $jobRole = $data['jobRole'];
    $experienceLevel = $data['experienceLevel'];
    $skills = !empty($data['skills']) ? $data['skills'] : 'not specified';
    $questionType = $data['questionType'];
    $additionalContext = !empty($data['additionalContext']) ? $data['additionalContext'] : '';
    
    $prompt = "Generate interview questions for a $experienceLevel $jobRole position. ";
    
    if ($skills !== 'not specified') {
        $prompt .= "Key skills/technologies required: $skills. ";
    }
    
    if (!empty($additionalContext)) {
        $prompt .= "Additional context: $additionalContext. ";
    }
    
    switch ($questionType) {
        case 'Technical':
            $prompt .= "Generate 10-15 technical questions that would assess the candidate's knowledge and skills. ";
            $prompt .= "Include questions about specific technologies, problem-solving, and practical scenarios. ";
            $prompt .= "Format the questions clearly with numbering.";
            break;
            
        case 'Behavioral':
            $prompt .= "Generate 10-15 behavioral questions that would assess the candidate's soft skills, personality, and cultural fit. ";
            $prompt .= "Include questions about teamwork, challenges, achievements, and work style. ";
            $prompt .= "Format the questions clearly with numbering.";
            break;
            
        case 'Both':
            $prompt .= "Generate 8-10 technical questions and 8-10 behavioral questions. ";
            $prompt .= "For technical questions, focus on specific technologies and problem-solving. ";
            $prompt .= "For behavioral questions, focus on teamwork, challenges, and work style. ";
            $prompt .= "Clearly separate the two sections with headings 'Technical Questions' and 'Behavioral Questions'.";
            break;
    }
    
    return $prompt;
}

function callOllama($prompt) {
    // Ollama API endpoint (adjust according to your setup)
    $ollamaUrl = 'http://localhost:11434/api/generate';
    
    // Prepare the data for Ollama
    $ollamaData = [
        'model' => 'llama3', // or any other model you're using
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 2000
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($ollamaUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ollamaData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute the request
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        curl_close($ch);
        return false;
    }
    
    curl_close($ch);
    
    // Decode the response
    $responseData = json_decode($response, true);
    
    if (!isset($responseData['response'])) {
        return false;
    }
    
    return $responseData['response'];
}

function parseResponse($response, $questionType) {
    $result = [];
    
    if ($questionType === 'Both') {
        // Split response into technical and behavioral sections
        $sections = explode("\n\n", $response);
        
        foreach ($sections as $section) {
            if (strpos($section, 'Technical Questions') !== false) {
                $result['technical'] = trim($section);
            } elseif (strpos($section, 'Behavioral Questions') !== false) {
                $result['behavioral'] = trim($section);
            }
        }
        
        // If sections weren't properly split, just return combined
        if (empty($result['technical']) || empty($result['behavioral'])) {
            $result['combined'] = $response;
            unset($result['technical']);
            unset($result['behavioral']);
        }
    } elseif ($questionType === 'Technical') {
        $result['technical'] = $response;
    } elseif ($questionType === 'Behavioral') {
        $result['behavioral'] = $response;
    }
    
    return $result;
}
?>