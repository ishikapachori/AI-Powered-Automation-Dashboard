function formatReport() {
  const input = document.getElementById('bulletInput').value;
  const outputDiv = document.getElementById('output');
  outputDiv.innerHTML = "⏳ Formatting report...";

  fetch('generate.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ bullets: input })
  })
  .then(response => response.text())
  .then(data => {
    outputDiv.innerHTML = data;
  })
  .catch(error => {
    outputDiv.innerHTML = "❌ Error formatting report.";
    console.error(error);
  });
}
