<?php
set_time_limit(300); // Increase time limit

$data = json_decode(file_get_contents("php://input"), true);
$bullets = $data["bullets"] ?? "";

if (!$bullets) {
    http_response_code(400);
    echo "No input provided.";
    exit;
}

$fullPrompt = "You are a professional business writer. Convert the following bullet updates into a formal daily or weekly status report with proper grammar and structure:\n\n" . $bullets;

$ch = curl_init("http://localhost:11434/api/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    "model" => "llama3",
    "prompt" => $fullPrompt,
    "stream" => false,
    "options" => [
        "num_predict" => 400
    ]
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json"
]);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    http_response_code(500);
    echo "CURL Error: " . curl_error($ch);
    exit;
}
curl_close($ch);

$responseData = json_decode($response, true);
echo $responseData["response"] ?? "No response from model.";
?>
