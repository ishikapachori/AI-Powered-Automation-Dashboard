<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
$requiredFields = ['jobTitle', 'department', 'experienceLevel', 'jobDescription'];
foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Missing required field: $field"]);
        exit;
    }
}

$jobTitle = $input['jobTitle'];
$department = $input['department'];
$experienceLevel = $input['experienceLevel'];
$jobDescription = $input['jobDescription'];
$specialRequirements = $input['specialRequirements'] ?? '';

// Prepare the prompt for Ollama/LLaMA3
$prompt = <<<PROMPT
Create a comprehensive onboarding guide for a new hire with the following details:

**Job Title:** $jobTitle
**Department:** $department
**Experience Level:** $experienceLevel
**Job Description:** $jobDescription
**Special Requirements:** $specialRequirements

The onboarding guide should include:

1. **First Week Schedule** (Day-by-day breakdown of activities)
2. **Key People to Meet** (Roles and why they're important)
3. **Tools & Systems Setup** (Step-by-step instructions)
4. **Training Plan** (What to learn and when)
5. **Key Documents to Review** (With links if possible)
6. **30-60-90 Day Goals** (Clear milestones)
7. **Department-Specific Resources**
8. **Company Culture Notes** (Norms and expectations)

Format the guide professionally with clear headings and bullet points. Include estimated time commitments where appropriate.
PROMPT;

// Call Ollama's API
$ollamaUrl = 'http://localhost:11434/api/generate';
$model = 'llama3'; // Change to your preferred model

$data = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.5,
        'max_tokens' => 2500,
        'top_p' => 0.9
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama connection failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Ollama API error: ' . $httpCode]);
    exit;
}

$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(502);
    echo json_encode(['error' => 'Invalid response from Ollama']);
    exit;
}

// Return the generated onboarding guide
echo json_encode([
    'guide' => $responseData['response']
]);
?>