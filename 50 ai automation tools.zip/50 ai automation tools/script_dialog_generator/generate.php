<?php
// generate.php - Backend for Script/Dialog Generator

// Set headers for JSON response
header('Content-Type: application/json');

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get form data
$topic = isset($_POST['topic']) ? trim($_POST['topic']) : '';
$language = isset($_POST['language']) ? trim($_POST['language']) : 'english';
$type = isset($_POST['type']) ? trim($_POST['type']) : 'film';
$characters = isset($_POST['characters']) ? (int)$_POST['characters'] : 2;
$tone = isset($_POST['tone']) ? trim($_POST['tone']) : 'dramatic';

// Validate input
if (empty($topic)) {
    http_response_code(400);
    echo json_encode(['error' => 'Topic is required']);
    exit;
}

// Construct the prompt for the LLM
$prompt = "Generate a " . $tone . " " . $type . " dialog for " . $characters . " characters based on the following topic/scene: " . $topic . ". ";
$prompt .= "The dialog should be in " . $language . " language. ";
$prompt .= "Format the output with character names and their dialogues clearly separated. ";

if ($type === 'ad') {
    $prompt .= "Make sure the dialog is persuasive and highlights product benefits. ";
} else {
    $prompt .= "Create an engaging and realistic conversation that fits the scene. ";
}

// Call Ollama API
$response = callOllamaAPI($prompt);

// Return the generated dialog
echo json_encode(['dialog' => $response]);
exit;

/**
 * Function to call Ollama API
 * 
 * @param string $prompt The prompt to send to Ollama
 * @return string The generated response
 */
function callOllamaAPI($prompt) {
    // Ollama API endpoint (assuming Ollama is running locally)
    $url = 'http://localhost:11434/api/generate';
    
    // Request data
    $data = [
        'model' => 'llama3', // Use LLaMA3 model or any available Ollama model
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'top_p' => 0.9,
            'max_tokens' => 1000
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return "Error connecting to Ollama API: " . $error;
    }
    
    // Close cURL
    curl_close($ch);
    
    // Parse response
    $responseData = json_decode($response, true);
    
    // Check if response contains the expected data
    if (isset($responseData['response'])) {
        return $responseData['response'];
    } else {
        // If there's an error or unexpected response format
        return "Error: Unexpected response from Ollama API. Please try again.";
    }
}
?>
