<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['destination', 'startDate', 'endDate', 'travelers', 'travelType'];
foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Missing required field: $field"]);
        exit;
    }
}

// Extract input data
$destination = $input['destination'];
$startDate = date('F j, Y', strtotime($input['startDate']));
$endDate = date('F j, Y', strtotime($input['endDate']));
$travelers = $input['travelers'];
$travelType = $input['travelType'];
$interests = $input['interests'] ?? '';

// Calculate trip duration
$start = new DateTime($input['startDate']);
$end = new DateTime($input['endDate']);
$duration = $start->diff($end)->days + 1;

// Prepare the prompt for Ollama/LLaMA3
$prompt = <<<PROMPT
Create a detailed travel itinerary for a trip to $destination from $startDate to $endDate ($duration days).

Travel Details:
- Type: $travelType trip
- Number of travelers: $travelers
- Special interests: $interests

The itinerary should include:
1. A title with destination and dates
2. Daily breakdown with:
   - Morning, afternoon, and evening activities
   - Recommended restaurants/cafes
   - Key attractions to visit
   - Travel tips for each day
3. A packing checklist tailored to:
   - The destination's climate
   - The trip duration
   - The travel type ($travelType)
4. Additional recommendations:
   - Local customs/etiquette
   - Transportation tips
   - Safety advice
   - Budgeting suggestions

Format the itinerary professionally with clear sections and bullet points. Make it practical and enjoyable.
PROMPT;

// Call Ollama's API
$ollamaUrl = 'http://localhost:11434/api/generate';
$model = 'llama3'; // Change to your preferred model

$data = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.7,
        'max_tokens' => 2000
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama connection failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Ollama API error: ' . $httpCode]);
    exit;
}

$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(502);
    echo json_encode(['error' => 'Invalid response from Ollama']);
    exit;
}

// Return the generated itinerary
echo json_encode([
    'itinerary' => $responseData['response']
]);
?>