<?php
header('Content-Type: application/json');
require_once 'vendor/autoload.php'; // Include Composer autoloader for Ollama

// Enable CORS if needed
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Process POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    
    try {
        switch ($action) {
            case 'generate_summary':
                $summary = generateBudgetSummary($input);
                echo json_encode([
                    'success' => true,
                    'summary' => $summary
                ]);
                break;
                
            default:
                echo json_encode([
                    'error' => 'Invalid action'
                ]);
                break;
        }
    } catch (Exception $e) {
        echo json_encode([
            'error' => $e->getMessage()
        ]);
    }
}

function generateBudgetSummary($data) {
    // In a real implementation, you would call Ollama/Llama3 API here
    // This is a simplified version that creates a basic summary
    
    $month = $data['month'];
    $tone = $data['tone'];
    $totalIncome = $data['totalIncome'];
    $totalExpenses = $data['totalExpenses'];
    $net = $data['net'];
    $notes = $data['notes'] ?? '';
    
    // Format income and expenses lists
    $incomeList = array_map(function($item) use ($totalIncome) {
        $percentage = ($item['amount'] / $totalIncome) * 100;
        return "- {$item['name']}: $" . number_format($item['amount'], 2) . 
               " (" . round($percentage, 1) . "%)";
    }, $data['income']);
    
    $expenseList = array_map(function($item) use ($totalExpenses) {
        $percentage = ($item['amount'] / $totalExpenses) * 100;
        return "- {$item['name']}: $" . number_format($item['amount'], 2) . 
               " (" . round($percentage, 1) . "%)";
    }, $data['expenses']);
    
    // Determine tone
    $toneOpening = [
        'professional' => "Financial Analysis for $month",
        'friendly' => "Here's your budget overview for $month",
        'concise' => "$month Budget Summary",
        'detailed' => "Comprehensive Financial Report: $month"
    ][$tone] ?? "Budget Summary for $month";
    
    // Generate summary
    $summary = "$toneOpening:\n\n";
    $summary .= "INCOME:\n" . implode("\n", $incomeList) . "\n";
    $summary .= "Total Income: $" . number_format($totalIncome, 2) . "\n\n";
    
    $summary .= "EXPENSES:\n" . implode("\n", $expenseList) . "\n";
    $summary .= "Total Expenses: $" . number_format($totalExpenses, 2) . "\n\n";
    
    if ($net >= 0) {
        $summary .= "NET SAVINGS: $" . number_format($net, 2) . "\n";
        $summary .= "Good financial position with surplus.\n";
    } else {
        $summary .= "NET DEFICIT: $" . number_format(abs($net), 2) . "\n";
        $summary .= "Review expenses to improve financial health.\n";
    }
    
    if (!empty($notes)) {
        $summary .= "\nNOTES:\n$notes\n";
    }
    
    // In a real app, you would call Ollama API here to enhance the summary
    // $ollamaResponse = callOllamaAPI($summary, $tone);
    // return $ollamaResponse['enhanced_summary'];
    
    return $summary;
}

// Example function to call Ollama API (would need proper implementation)
function callOllamaAPI($prompt, $tone) {
    /*
    // Example using Ollama's PHP client (hypothetical)
    $client = new Ollama\Client();
    
    $response = $client->generate([
        'model' => 'llama3',
        'prompt' => "Convert this budget data into a $tone financial summary:\n$prompt",
        'format' => 'text',
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 1000
        ]
    ]);
    
    return [
        'enhanced_summary' => $response['output']
    ];
    */
    
    // For now, just return the basic summary
    return [
        'enhanced_summary' => $prompt
    ];
}
?>