<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['assetType']) || !isset($input['urgency'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$assetType = $input['assetType'];
$urgency = $input['urgency'];
$additionalInfo = $input['additionalInfo'] ?? '';

// Prepare the prompt for LLaMA3
$prompt = <<<PROMPT
Generate a formal asset request document based on the following information:

Asset Type: $assetType
Urgency Level: $urgency
Additional Information: $additionalInfo

The document should include:
1. A professional header with "Asset Request Form" title
2. Date of request
3. Requester details section (leave placeholders for name, department, etc.)
4. Detailed description of the requested asset
5. Justification for the request
6. Urgency explanation based on the provided level
7. Any special requirements or notes
8. Signature line

Format the document professionally with appropriate sections and line breaks.
PROMPT;

// Call Ollama's LLaMA3 API
$ollamaUrl = 'http://localhost:11434/api/generate'; // Default Ollama URL
$model = 'llama3'; // Change this if using a different model

$data = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.7,
        'max_tokens' => 1500
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama connection failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Ollama API returned error code: ' . $httpCode]);
    exit;
}

$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(502);
    echo json_encode(['error' => 'Invalid response from Ollama']);
    exit;
}

// Return the generated text
echo json_encode([
    'generatedText' => $responseData['response']
]);
?>