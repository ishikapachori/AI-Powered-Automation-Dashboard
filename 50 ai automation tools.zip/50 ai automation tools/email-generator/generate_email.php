<?php
// generate_email.php

// Set headers for JSON response
header('Content-Type: application/json');

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check if data is valid
if (!$data || !isset($data['purpose']) || !isset($data['tone'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid input data'
    ]);
    exit;
}

// Extract data
$purpose = $data['purpose'];
$tone = $data['tone'];
$details = isset($data['details']) ? $data['details'] : '';

// Function to connect to Ollama API
function generateEmailWithOllama($purpose, $tone, $details) {
    // Ollama API endpoint
    $url = 'http://localhost:11434/api/generate';
    
    // Create a prompt for the LLM
    $prompt = "Generate a professional email with the following parameters:
    - Purpose: {$purpose}
    - Tone: {$tone}
    - Additional details: {$details}
    
    Please format the email with a proper subject line, greeting, body, and sign-off. Make it ready to send without requiring any edits.";
    
    // Prepare the request data
    $requestData = [
        'model' => 'llama3',  // Use LLaMA3 model
        'prompt' => $prompt,
        'stream' => false
    ];
    
    // Initialize cURL session
    $ch = curl_init($url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        curl_close($ch);
        return [
            'success' => false,
            'message' => 'Error connecting to Ollama API: ' . curl_error($ch)
        ];
    }
    
    // Close cURL session
    curl_close($ch);
    
    // Decode the response
    $responseData = json_decode($response, true);
    
    // Check if response is valid
    if (!$responseData || !isset($responseData['response'])) {
        return [
            'success' => false,
            'message' => 'Invalid response from Ollama API'
        ];
    }
    
    // Return the generated email
    return [
        'success' => true,
        'email' => $responseData['response']
    ];
}

// Generate the email using Ollama
$result = generateEmailWithOllama($purpose, $tone, $details);

// Return the result
echo json_encode($result);
?>
