<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = trim($_POST["input"]);
    $language = trim($_POST["language"]);

    $prompt = "Translate the following text into " . $language . ":\n\n\"$input\"\n\nTranslation:";

    $payload = json_encode([
        "model" => "llama3",
        "prompt" => $prompt,
        "stream" => false
    ]);

    $ch = curl_init("http://localhost:11434/api/generate");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
    echo $result["response"] ?? "No response from the AI model.";
}
?>
