<?php
header('Content-Type: application/json');

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get the blog title from the request
$blogTitle = isset($_POST['blogTitle']) ? trim($_POST['blogTitle']) : '';

if (empty($blogTitle)) {
    echo json_encode([
        'success' => false,
        'message' => 'Blog title is required'
    ]);
    exit;
}

// Function to communicate with Ollama API
function generateContentWithOllama($prompt) {
    $data = [
        'model' => 'llama3',  // Using LLaMA3 model
        'prompt' => $prompt,
        'stream' => false     // We want a complete response, not streaming
    ];
    
    $ch = curl_init('http://localhost:11434/api/generate');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error || $statusCode !== 200) {
        return [
            'success' => false,
            'message' => "API Error: $error (Status code: $statusCode)"
        ];
    }
    
    $responseData = json_decode($response, true);
    
    if (!$responseData || !isset($responseData['response'])) {
        return [
            'success' => false,
            'message' => 'Invalid response from Ollama API'
        ];
    }
    
    return [
        'success' => true,
        'content' => $responseData['response']
    ];
}

// Create the prompt for Ollama
$prompt = <<<EOT
I need to create a comprehensive blog post outline for the title: "$blogTitle"

Please generate 5-7 main sections for this blog post. For each section:
1. Provide a compelling section heading
2. Write a brief description of what this section should cover (2-3 sentences)
3. Suggest 3-5 key points or subtopics to include in this section

Format the response as structured content that I can easily parse. Make sure the sections flow logically and cover the topic comprehensively.
EOT;

// Call Ollama API
$ollamaResponse = generateContentWithOllama($prompt);

if (!$ollamaResponse['success']) {
    echo json_encode([
        'success' => false,
        'message' => $ollamaResponse['message']
    ]);
    exit;
}

// Process the response to extract sections
$content = $ollamaResponse['content'];

// Simple parsing logic - this could be improved with more sophisticated parsing
$sections = [];
$sectionPattern = '/Section\s*\d+\s*:?\s*(.*?)(?=Section\s*\d+\s*:|$)/is';
preg_match_all($sectionPattern, $content, $matches);

if (!empty($matches[0])) {
    foreach ($matches[0] as $index => $sectionText) {
        // Extract section title
        $titlePattern = '/Section\s*\d+\s*:?\s*(.*?)[\r\n]/i';
        preg_match($titlePattern, $sectionText, $titleMatch);
        $title = isset($titleMatch[1]) ? trim($titleMatch[1]) : "Section " . ($index + 1);
        
        // Remove the title from the content
        $sectionContent = preg_replace($titlePattern, '', $sectionText, 1);
        $sectionContent = trim($sectionContent);
        
        // Convert the content to HTML
        $sectionContent = nl2br($sectionContent);
        
        // Add to sections array
        $sections[] = [
            'title' => $title,
            'content' => $sectionContent
        ];
    }
} else {
    // If the pattern matching failed, just split the content into paragraphs
    $paragraphs = explode("\n\n", $content);
    foreach ($paragraphs as $index => $paragraph) {
        if (trim($paragraph)) {
            $sections[] = [
                'title' => "Key Point " . ($index + 1),
                'content' => nl2br(trim($paragraph))
            ];
        }
    }
}

// Return the processed content
echo json_encode([
    'success' => true,
    'sections' => $sections
]);
