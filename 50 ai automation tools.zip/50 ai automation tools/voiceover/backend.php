<?php
// backend.php

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$topic = trim($data["topic"] ?? '');

if (!$topic) {
    echo json_encode(["script" => "No topic provided."]);
    exit;
}

$prompt = "You are a voiceover script writer for YouTube Shorts. Write a short and catchy video script (under 120 words) in both Hindi and English for the topic: \"$topic\". Use Hindi and English mixed sentences that are friendly and suitable for narration.";

$payload = json_encode([
    "model" => "llama3",
    "prompt" => $prompt,
    "stream" => true
]);

$ch = curl_init("http://localhost:11434/api/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);

$response = curl_exec($ch);
curl_close($ch);

// Ollama streams multiple JSON lines
$lines = explode("\n", $response);
$final = "";

foreach ($lines as $line) {
    if ($line) {
        $json = json_decode($line, true);
        if (isset($json["response"])) {
            $final .= $json["response"];
        }
    }
}

echo json_encode(["script" => trim($final)]);
