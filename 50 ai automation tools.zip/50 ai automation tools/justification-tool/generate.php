<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate input
if (!$data || !isset($data['itemName']) || !isset($data['itemDescription'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid input: itemName and itemDescription are required']);
    exit;
}

// Prepare the prompt for LLaMA/Ollama
$prompt = "Create a professional procurement justification for the following item:\n\n";
$prompt .= "Item Name: " . $data['itemName'] . "\n";
$prompt .= "Description: " . $data['itemDescription'] . "\n";

if (!empty($data['additionalInfo'])) {
    $prompt .= "Additional Information: " . $data['additionalInfo'] . "\n";
}

$prompt .= "\nThe justification should include:\n";
$prompt .= "- Business need and purpose\n";
$prompt .= "- Benefits to the organization\n";
$prompt .= "- Cost-effectiveness analysis\n";
$prompt .= "- Alternatives considered\n";
$prompt .= "- Risk assessment of not procuring\n";
$prompt .= "- Recommended solution\n\n";
$prompt .= "Please format the response with clear headings for each section.";

// Ollama API configuration
$ollamaUrl = 'http://localhost:11434/api/generate'; // Default Ollama API endpoint
$model = 'llama3'; // Change this to your preferred model

// Prepare the request data for Ollama
$ollamaData = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.7,
        'max_tokens' => 1500
    ]
];

// Initialize cURL session
$ch = curl_init($ollamaUrl);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ollamaData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Execute the request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama API request failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

// Close cURL session
curl_close($ch);

// Decode the response
$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Invalid response from Ollama API']);
    exit;
}

// Return the generated justification
echo json_encode([
    'justification' => $responseData['response']
]);
?>