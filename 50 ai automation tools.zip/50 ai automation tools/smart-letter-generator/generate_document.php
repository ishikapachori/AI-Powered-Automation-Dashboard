<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['prompt']) || empty($input['prompt'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt is required']);
    exit;
}

$documentType = $input['type'] ?? 'notice';
$title = $input['title'] ?? '';
$prompt = $input['prompt'];
$tone = $input['tone'] ?? 'professional';

// Prepare the prompt for LLaMA3
$systemPrompt = "You are a professional document generator assistant. Create a $documentType document";
if ($title) {
    $systemPrompt .= " titled '$title'";
}
$systemPrompt .= ". Use a $tone tone. Format the document professionally with appropriate headings and structure.";

$userPrompt = "Generate a $documentType based on these instructions: $prompt";

// Call Ollama API (LLaMA3)
$ollamaUrl = 'http://localhost:11434/api/generate'; // Default Ollama URL
$model = 'llama3'; // or whatever model you're using

$data = [
    'model' => $model,
    'prompt' => $systemPrompt . "\n\n" . $userPrompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.7,
        'max_tokens' => 2000
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate document']);
    exit;
}

$responseData = json_decode($response, true);

// Extract the generated content
$generatedContent = $responseData['response'] ?? '';

// Format the document with title if provided
$document = '';
if ($title) {
    $document .= strtoupper($title) . "\n\n";
}
$document .= $generatedContent;

// Return the generated document
echo json_encode(['document' => $document]);
?>