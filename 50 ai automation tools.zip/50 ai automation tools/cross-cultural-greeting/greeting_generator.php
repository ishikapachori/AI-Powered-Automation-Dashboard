<?php
// greeting_generator.php

// Set headers for JSON response
header('Content-Type: application/json');

// Get form data
$country = isset($_POST['country']) ? $_POST['country'] : '';
$context = isset($_POST['context']) ? $_POST['context'] : '';
$custom = isset($_POST['custom']) ? $_POST['custom'] : '';

// Construct the prompt for the AI
if (!empty($custom)) {
    $prompt = $custom;
} else {
    $contextMap = [
        'business' => 'in a business meeting',
        'teacher' => 'when meeting a teacher or professor',
        'friend' => 'when meeting a friend',
        'elder' => 'when meeting an elder',
        'firsttime' => 'during a first-time introduction'
    ];
    
    $contextPhrase = isset($contextMap[$context]) ? $contextMap[$context] : '';
    $prompt = "How to greet someone in " . ucfirst($country) . " " . $contextPhrase . "? Include the greeting in the native language, pronunciation, and cultural etiquette notes.";
}

// Ollama API configuration
$ollamaEndpoint = "http://localhost:11434/api/generate";
$model = "llama3"; // You can change this to any available Ollama model

// Prepare the data for Ollama API
$data = [
    "model" => $model,
    "prompt" => $prompt,
    "stream" => false
];

// Initialize cURL session
$ch = curl_init($ollamaEndpoint);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Execute the cURL request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo json_encode([
        'error' => true,
        'message' => 'cURL Error: ' . curl_error($ch)
    ]);
    exit;
}

// Close cURL session
curl_close($ch);

// Process the response
$responseData = json_decode($response, true);

if (isset($responseData['response'])) {
    // Parse the AI response to extract relevant information
    $aiResponse = $responseData['response'];
    
    // Simple parsing logic - in a production environment, you might want more sophisticated parsing
    $title = "Greeting in " . ucfirst($country);
    
    // Extract greeting, pronunciation, and cultural note
    $greeting = "";
    $pronunciation = "";
    $culturalNote = "";
    
    // Very basic parsing - in production, use more robust methods
    if (preg_match('/greeting:?\s*([^\n]+)/i', $aiResponse, $matches)) {
        $greeting = $matches[1];
    }
    
    if (preg_match('/pronunciation:?\s*([^\n]+)/i', $aiResponse, $matches)) {
        $pronunciation = $matches[1];
    }
    
    if (preg_match('/cultural note:?\s*([\s\S]+)/i', $aiResponse, $matches)) {
        $culturalNote = $matches[1];
    } else if (preg_match('/etiquette:?\s*([\s\S]+)/i', $aiResponse, $matches)) {
        $culturalNote = $matches[1];
    }
    
    // If parsing fails, use the entire response as the greeting
    if (empty($greeting) && empty($pronunciation) && empty($culturalNote)) {
        $greeting = $aiResponse;
    }
    
    // Return the structured response
    echo json_encode([
        'title' => $title,
        'greeting' => $greeting,
        'pronunciation' => $pronunciation,
        'culturalNote' => $culturalNote,
        'fullResponse' => $aiResponse // Include the full response for debugging
    ]);
} else {
    echo json_encode([
        'error' => true,
        'message' => 'Invalid response from AI service',
        'rawResponse' => $response
    ]);
}
?>
