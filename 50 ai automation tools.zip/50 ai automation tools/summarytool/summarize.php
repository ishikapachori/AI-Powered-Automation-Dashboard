<?php
// summarize.php - Backend for Auto Summary Tool

// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the raw POST data
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Validate input
if (!isset($data['text']) || empty($data['text'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No text provided for summarization']);
    exit;
}

// Get summary type (default to bullets if not specified)
$summaryType = isset($data['type']) ? $data['type'] : 'bullets';

// Prepare the prompt based on summary type
$prompt = preparePrompt($data['text'], $summaryType);

// Call Ollama API to get the summary
$summary = callOllamaAPI($prompt);

// Return the summary
echo json_encode(['summary' => $summary]);

/**
 * Prepare a prompt for the LLaMA3 model based on the input text and summary type
 */
function preparePrompt($text, $summaryType) {
    $instructions = '';
    
    switch ($summaryType) {
        case 'paragraph':
            $instructions = "Summarize the following text into a concise paragraph:";
            break;
        case 'headline':
            $instructions = "Create a brief headline that captures the main point of the following text:";
            break;
        case 'bullets':
        default:
            $instructions = "Summarize the following text into key bullet points:";
            break;
    }
    
    return $instructions . "\n\n" . $text;
}

/**
 * Call the Ollama API with LLaMA3 model to generate a summary
 */
function callOllamaAPI($prompt) {
    // Ollama API endpoint (assuming Ollama is running locally)
    $url = 'http://localhost:11434/api/generate';
    
    // Prepare the request data
    $requestData = [
        'model' => 'llama3', // Use LLaMA3 model
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.3, // Lower temperature for more focused summaries
            'top_p' => 0.9,
            'max_tokens' => 500 // Limit response length
        ]
    ];
    
    // Initialize cURL session
    $ch = curl_init($url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    // Execute the request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        curl_close($ch);
        return 'Error connecting to Ollama API: ' . curl_error($ch);
    }
    
    // Close the cURL session
    curl_close($ch);
    
    // Parse the response
    $responseData = json_decode($response, true);
    
    // Return the generated text or an error message
    if (isset($responseData['response'])) {
        return $responseData['response'];
    } else {
        return 'Error: Unable to generate summary. Please try again.';
    }
}
?>
