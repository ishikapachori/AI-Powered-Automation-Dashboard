<?php
// validate_translation.php

// Set headers to handle JSON requests and responses
header('Content-Type: application/json');

// Get the raw POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Check if all required data is present
if (!isset($data['originalText']) || !isset($data['translation1']) || 
    !isset($data['translation2']) || !isset($data['originalLang']) || 
    !isset($data['translation1Lang']) || !isset($data['translation2Lang'])) {
    
    http_response_code(400);
    echo json_encode(['error' => 'Missing required data']);
    exit;
}

// Extract data
$originalText = $data['originalText'];
$translation1 = $data['translation1'];
$translation2 = $data['translation2'];
$originalLang = $data['originalLang'];
$translation1Lang = $data['translation1Lang'];
$translation2Lang = $data['translation2Lang'];

// Prepare the prompt for LLaMA3
$prompt = "You are a professional translation validator. Please compare these two translations of the original text and determine which one is more accurate. Provide a detailed explanation of your assessment, including specific examples of where one translation is better than the other.

Original Text ($originalLang): $originalText

Translation 1 ($translation1Lang): $translation1

Translation 2 ($translation2Lang): $translation2

Please evaluate both translations based on:
1. Accuracy to the original meaning
2. Natural language flow
3. Cultural context and appropriateness
4. Technical terminology (if applicable)

Which translation is more accurate and why?";

// Call Ollama API with LLaMA3 model
$result = callOllamaAPI($prompt);

// Return the result
echo json_encode(['result' => $result]);

/**
 * Function to call Ollama API
 * @param string $prompt The prompt to send to the model
 * @return string The formatted response from the model
 */
function callOllamaAPI($prompt) {
    // Ollama API endpoint (assuming Ollama is running locally)
    $url = 'http://localhost:11434/api/generate';
    
    // Prepare the request data
    $requestData = [
        'model' => 'llama3',  // Use LLaMA3 model
        'prompt' => $prompt,
        'stream' => false     // We want the complete response at once
    ];
    
    // Initialize cURL session
    $ch = curl_init($url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120); // Set a longer timeout for LLM processing
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        curl_close($ch);
        return 'Error: ' . curl_error($ch);
    }
    
    // Close cURL session
    curl_close($ch);
    
    // Parse the JSON response
    $responseData = json_decode($response, true);
    
    // Check if the response contains the expected data
    if (isset($responseData['response'])) {
        // Format the response with HTML for better display
        $formattedResponse = nl2br(htmlspecialchars($responseData['response']));
        
        // Add some basic formatting to highlight key points
        $formattedResponse = preg_replace('/Translation 1/i', '<strong>Translation 1</strong>', $formattedResponse);
        $formattedResponse = preg_replace('/Translation 2/i', '<strong>Translation 2</strong>', $formattedResponse);
        $formattedResponse = preg_replace('/more accurate/i', '<strong style="color: green;">more accurate</strong>', $formattedResponse);
        
        return $formattedResponse;
    } else {
        return 'Error: Unexpected response format from the AI model';
    }
}
?>
