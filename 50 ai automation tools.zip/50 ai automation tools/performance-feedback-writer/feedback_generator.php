<?php
header('Content-Type: application/json');

// Get the JSON data from the request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input data
if (!$data || 
    empty($data['employeeName']) || 
    empty($data['jobTitle']) || 
    empty($data['department']) || 
    empty($data['reviewPeriod']) || 
    empty($data['strengths']) || 
    empty($data['weaknesses']) || 
    empty($data['rating'])) {
    
    echo json_encode(['error' => 'All required fields must be provided']);
    exit;
}

// Prepare the prompt for LLaMA/Ollama
$prompt = "Generate a professional performance feedback for an employee with the following details:
- Employee Name: {$data['employeeName']}
- Job Title: {$data['jobTitle']}
- Department: {$data['department']}
- Review Period: {$data['reviewPeriod']}
- Key Strengths: {$data['strengths']}
- Areas for Improvement: {$data['weaknesses']}
- Overall Rating: {$data['rating']}/5
" . (!empty($data['additionalNotes']) ? "- Additional Notes: {$data['additionalNotes']}\n" : "") . "

The feedback should be structured as follows:
1. Opening paragraph summarizing overall performance
2. Detailed strengths with specific examples if available
3. Constructive feedback on areas for improvement
4. Closing paragraph with next steps and encouragement
5. Overall rating explanation

Use professional, constructive language. Keep it between 300-500 words.";

// Call Ollama API (adjust the endpoint as needed)
$ollamaResponse = callOllamaAPI($prompt);

if ($ollamaResponse === false) {
    echo json_encode(['error' => 'Failed to generate feedback. Please try again.']);
    exit;
}

// Return the generated feedback
echo json_encode(['feedback' => $ollamaResponse]);

function callOllamaAPI($prompt) {
    // Adjust this URL to your Ollama server endpoint
    $ollamaUrl = 'http://localhost:11434/api/generate';
    
    // Prepare the data for Ollama
    $ollamaData = [
        'model' => 'llama3', // or any other model you're using
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 1000
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($ollamaUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ollamaData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute the request
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        error_log('Ollama API error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }
    
    curl_close($ch);
    
    // Parse the response
    $responseData = json_decode($response, true);
    
    if (isset($responseData['response'])) {
        return trim($responseData['response']);
    } else {
        error_log('Ollama API unexpected response: ' . $response);
        return false;
    }
}
?>