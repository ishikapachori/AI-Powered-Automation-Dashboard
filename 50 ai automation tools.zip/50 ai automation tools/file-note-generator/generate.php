<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

// Get the JSON data from the request body
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (empty($input['fileNumber']) || empty($input['summary'])) {
    echo json_encode(['error' => 'File number and summary are required']);
    exit;
}

$fileNumber = trim($input['fileNumber']);
$summary = trim($input['summary']);
$tone = isset($input['tone']) ? $input['tone'] : 'professional';

// Prepare the prompt for LLaMA3
$prompt = "Generate a professional file note based on the following information:
- File Number: $fileNumber
- Summary: $summary

The note should be in a $tone tone and follow standard file note formatting. Include the date and make it clear and concise.";

// Here you would normally call the Ollama API to get the response
// For this example, we'll simulate a response
$simulatedResponse = "FILE NOTE\n\nDate: " . date('Y-m-d') . "\nFile Number: $fileNumber\n\n" . 
                     "Summary of Action:\n" . 
                     wordwrap(ucfirst($summary), 75, "\n") . "\n\n" . 
                     "Notes:\n" . 
                     "1. Reviewed the file contents and relevant documentation.\n" . 
                     "2. Verified all necessary information is complete and accurate.\n" . 
                     "3. Next steps include following up on any outstanding items.\n\n" . 
                     "Action Required:\n" . 
                     "- Please review and provide any additional information if needed.\n\n" . 
                     "Prepared by: [Your Name]";

// In a real implementation, you would call the Ollama API like this:
/*
$url = 'http://localhost:11434/api/generate'; // Ollama API endpoint
$data = [
    'model' => 'llama3',
    'prompt' => $prompt,
    'stream' => false
];

$options = [
    'http' => [
        'header' => "Content-type: application/json\r\n",
        'method' => 'POST',
        'content' => json_encode($data)
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
    echo json_encode(['error' => 'Failed to generate note']);
    exit;
}

$response = json_decode($result, true);
$note = $response['response'] ?? 'Unable to generate note';
*/

// For this example, we'll use the simulated response
$note = $simulatedResponse;

echo json_encode(['note' => $note]);
?>