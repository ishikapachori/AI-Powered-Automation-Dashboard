<?php
// Set headers to handle AJAX requests properly
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// Function to sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Function to call Ollama API
function callOllama($prompt, $model = "llama3") {
    $url = "http://localhost:11434/api/generate";
    
    $data = [
        "model" => $model,
        "prompt" => $prompt,
        "stream" => false
    ];
    
    $options = [
        "http" => [
            "header" => "Content-Type: application/json\r\n",
            "method" => "POST",
            "content" => json_encode($data),
            "timeout" => 120
        ]
    ];
    
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    
    if ($result === FALSE) {
        return ["success" => false, "message" => "Failed to connect to Ollama API"];
    }
    
    return json_decode($result, true);
}

// Check if this is a POST request with JSON data
$input = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $input) {
    // Validate required parameters
    if (!isset($input['text']) || empty($input['text'])) {
        echo json_encode([
            'success' => false,
            'message' => 'No text provided for summarization'
        ]);
        exit;
    }
    
    $text = $input['text'];
    $format = isset($input['format']) ? $input['format'] : 'bullet';
    
    // Validate and sanitize format
    if ($format !== 'bullet' && $format !== 'paragraph') {
        $format = 'bullet'; // Default to bullet points if invalid
    }
    
    // Create the prompt for LLaMA3
    $formatInstruction = $format === 'bullet' 
        ? "as a concise bullet-point list with the most important points" 
        : "as a short, coherent paragraph that captures the essential information";
    
    $prompt = <<<EOT
You are a highly skilled AI text summarizer. Analyze the following text and create a summary $formatInstruction.
Focus on the main ideas and key information only. Be concise but comprehensive.

TEXT TO SUMMARIZE:
$text

SUMMARY:
EOT;

    // Call Ollama API
    $response = callOllama($prompt);
    
    // Process the response
    if (isset($response['response'])) {
        $summary = $response['response'];
        
        // Format the summary based on the requested format
        if ($format === 'bullet' && strpos($summary, '•') === false && strpos($summary, '-') === false) {
            // If bullets weren't generated, add them
            $lines = explode("\n", trim($summary));
            $formattedSummary = '';
            foreach ($lines as $line) {
                $line = trim($line);
                if (!empty($line)) {
                    $formattedSummary .= "• " . $line . "<br>";
                }
            }
            $summary = $formattedSummary;
        } else {
            // For paragraph format or already bulleted content
            $summary = nl2br($summary);
        }
        
        echo json_encode([
            'success' => true,
            'summary' => $summary
        ]);
    } else {
        // Handle error from Ollama
        $errorMsg = isset($response['message']) ? $response['message'] : 'Unknown error from LLM service';
        echo json_encode([
            'success' => false,
            'message' => $errorMsg
        ]);
    }
} else {
    // Return error if not a POST request or missing JSON data
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request. Please send a POST request with JSON data.'
    ]);
}
?>