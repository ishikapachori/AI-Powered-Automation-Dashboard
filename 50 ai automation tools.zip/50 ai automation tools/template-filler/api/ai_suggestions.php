<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data || !isset($data['template_type'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid input data']);
    exit;
}

$templateType = $data['template_type'];

// In a real implementation, this would call Ollama/LLaMA3 API
// This is a mock implementation for demonstration
$suggestions = [
    'certificate' => "Consider adding specific details about the achievement. For technical certifications, include the technologies or skills demonstrated. For performance awards, mention specific contributions or metrics.",
    'noc' => "Make sure to include the exact purpose of the NOC (study, visa, new employment). Specify if there are any conditions or limitations. Include official company contact information.",
    'offer-letter' => "Clearly state all compensation details (salary, bonuses, equity). Include probation period if applicable. Mention benefits (health insurance, retirement plans). Add a clear acceptance deadline.",
    'experience-letter' => "Highlight key projects and achievements. Mention soft skills and teamwork if relevant. Include the employee's reliability and attendance record if positive. State eligibility for rehire.",
    'appointment-letter' => "Clearly define the job title and reporting structure. Specify the work location (office, remote, hybrid). Include any probation period and evaluation criteria. Mention any special conditions.",
    'custom' => "For custom templates, ensure all placeholders match your data keys. Consider adding conditional sections wrapped in [if:Condition]...[/if]. Use [today] for current date placeholder."
];

if (isset($suggestions[$templateType])) {
    echo json_encode([
        'success' => true,
        'suggestion' => $suggestions[$templateType]
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'No suggestions available for this template type'
    ]);
}

// Real implementation would call Ollama like this:
/*
$ollamaUrl = 'http://localhost:11434/api/generate'; // Ollama API endpoint
$prompt = "Provide professional suggestions for improving a $templateType template...";

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'model' => 'llama3',
    'prompt' => $prompt,
    'stream' => false
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$suggestion = $result['response'] ?? 'No suggestion available';
*/
?>