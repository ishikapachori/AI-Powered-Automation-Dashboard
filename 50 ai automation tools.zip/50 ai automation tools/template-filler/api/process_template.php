<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data || !isset($data['template']) || !isset($data['data'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid input data']);
    exit;
}

$template = $data['template'];
$staffData = $data['data'];

// Simple template processing - replace placeholders with data
$filledTemplate = preg_replace_callback(
    '/\[([^\]]+)\]/',
    function($matches) use ($staffData) {
        $key = $matches[1];
        return isset($staffData[$key]) ? $staffData[$key] : $matches[0];
    },
    $template
);

echo json_encode([
    'success' => true,
    'filled_template' => $filledTemplate
]);
?>