<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (empty($input['message'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Message is required']);
    exit;
}

$userMessage = $input['message'];
$department = $input['department'] ?? 'all';

// Define context based on department
$contexts = [
    'all' => "You are an expert on all company policies including HR, Finance, IT, and SOPs.",
    'hr' => "You are an HR policy expert. Focus on employee handbook, benefits, leave policies, conduct rules, and HR procedures.",
    'finance' => "You are a finance policy expert. Focus on expense reporting, reimbursement, budgets, approvals, and financial controls.",
    'it' => "You are an IT policy expert. Focus on security, acceptable use, data protection, passwords, and IT procedures.",
    'sop' => "You are an SOP expert. Focus on standard operating procedures for all departments."
];

$context = $contexts[$department] ?? $contexts['all'];

// Prepare the prompt for Ollama/LLaMA3
$prompt = <<<PROMPT
$context

You are an AI assistant for ITG company employees. Provide accurate, concise answers about company policies based on the following rules:

1. Always be professional and polite
2. If a question is outside policy scope, say so
3. For complex policies, break down into bullet points
4. When referencing documents, include document names and sections
5. If unsure, direct to the appropriate department contact

Current conversation:
User: $userMessage

Assistant:
PROMPT;

// Call Ollama's API
$ollamaUrl = 'http://localhost:11434/api/generate';
$model = 'llama3'; // Change to your preferred model

$data = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.3, // Lower for more factual responses
        'max_tokens' => 1500,
        'top_p' => 0.9
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama connection failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Ollama API error: ' . $httpCode]);
    exit;
}

$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(502);
    echo json_encode(['error' => 'Invalid response from Ollama']);
    exit;
}

// Return the generated response
echo json_encode([
    'response' => $responseData['response']
]);
?>