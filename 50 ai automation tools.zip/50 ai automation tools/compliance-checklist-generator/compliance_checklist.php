<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (empty($input['activity']) || empty($input['industry']) || empty($input['complianceTypes'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$activity = $input['activity'];
$industry = $input['industry'];
$complianceTypes = implode(', ', $input['complianceTypes']);

// Prepare the prompt for Ollama/LLaMA3
$prompt = <<<PROMPT
Generate a detailed compliance checklist for the following business activity:

**Activity:** $activity
**Industry:** $industry
**Compliance Frameworks:** $complianceTypes

The checklist should:
1. Cover all relevant requirements from the specified compliance frameworks
2. Be tailored to the described industry
3. Include specific actions needed to achieve compliance
4. Organize items by compliance framework
5. Use clear, actionable language
6. Mark any industry-specific requirements

Format the output as a numbered list with each item on a new line. For each framework, include a section header like:
"[Framework] Requirements:"
followed by the specific checklist items.

Provide at least 5 items per framework, focusing on the most critical requirements.
PROMPT;

// Call Ollama's API
$ollamaUrl = 'http://localhost:11434/api/generate';
$model = 'llama3'; // Change to your preferred model

$data = [
    'model' => $model,
    'prompt' => $prompt,
    'stream' => false,
    'options' => [
        'temperature' => 0.3, // Lower for more factual responses
        'max_tokens' => 2000,
        'top_p' => 0.9
    ]
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ollama connection failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Ollama API error: ' . $httpCode]);
    exit;
}

$responseData = json_decode($response, true);

if (!isset($responseData['response'])) {
    http_response_code(502);
    echo json_encode(['error' => 'Invalid response from Ollama']);
    exit;
}

// Process the response into checklist items
$checklistResponse = $responseData['response'];
$checklistItems = [];

// Split by lines and filter out empty lines and section headers
$lines = explode("\n", $checklistResponse);
foreach ($lines as $line) {
    $trimmedLine = trim($line);
    
    // Skip empty lines and section headers (lines ending with :)
    if (!empty($trimmedLine) && !preg_match('/:$/', $trimmedLine)) {
        // Remove bullet points or numbers if present
        $cleanLine = preg_replace('/^\s*[\d•\-]+\.?\s*/', '', $trimmedLine);
        $checklistItems[] = $cleanLine;
    }
}

// Return the generated checklist
echo json_encode([
    'checklist' => $checklistItems
]);
?>