<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["text"])) {
    $rawData = trim($_POST["text"]);

    $prompt = "Convert the following raw data, logs, or observations into a structured, formal report:\n\n" . $rawData;

    $payload = [
        "model" => "llama3", // change if using another model
        "prompt" => $prompt,
        "stream" => false
    ];

    $ch = curl_init("http://localhost:11434/api/generate");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "Error: " . curl_error($ch);
    } else {
        $result = json_decode($response, true);
        echo $result["response"];
    }

    curl_close($ch);
} else {
    echo "No input received.";
}
?>
