<?php
// grammar_check.php

header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    exit(0);
}

header('Access-Control-Allow-Origin: *');

// Validate input
if (!isset($_POST['text']) || trim($_POST['text']) === '') {
    echo json_encode([
        'success' => false,
        'message' => 'No text provided for grammar checking.'
    ]);
    exit;
}

$text = trim($_POST['text']);

// Prepare prompt for Ollama to check grammar and correct the text
$prompt = "Correct the grammar and spelling mistakes in the following text. Provide only the corrected text without explanations:\n\n\"$text\"";

// Ollama API endpoint
$ollama_url = 'http://localhost:11434/api/generate';

// Request payload
$postData = json_encode([
    'model' => 'llama3',  // Change if you have a different model
    'prompt' => $prompt,
    'max_tokens' => 500,
    'temperature' => 0.2,
    'stream' => false
]);

// Initialize cURL
$ch = curl_init($ollama_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    $error_msg = curl_error($ch);
    curl_close($ch);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to connect to Ollama API: ' . $error_msg
    ]);
    exit;
}

curl_close($ch);

$result = json_decode($response, true);

// Check if response contains the corrected text
if ($result && isset($result['response'])) {
    $correctedText = trim($result['response']);

    echo json_encode([
        'success' => true,
        'correctedText' => $correctedText
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid response from Ollama API.'
    ]);
}
?>
