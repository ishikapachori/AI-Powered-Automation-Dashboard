<?php
header('Content-Type: application/json');

// Error handling
set_error_handler(function($severity, $message, $file, $line) {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

try {
    // Get the POST data
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid input data');
    }
    
    // Validate input
    if (isset($input['isReply']) && $input['isReply']) {
        // Reply email validation
        if (empty($input['originalEmail']) || empty($input['keyPoints'])) {
            throw new Exception('Original email and key points are required for replies');
        }
        
        $prompt = generateReplyPrompt($input['originalEmail'], $input['keyPoints'], $input['tone']);
    } else {
        // New email validation
        if (empty($input['recipient']) || empty($input['subject']) || empty($input['keyPoints'])) {
            throw new Exception('Recipient, subject, and key points are required for new emails');
        }
        
        $prompt = generateNewEmailPrompt(
            $input['recipient'], 
            $input['subject'], 
            $input['keyPoints'], 
            $input['tone'], 
            $input['length']
        );
    }
    
    // Call Ollama API (LLaMA3 or other model)
    $generatedEmail = callOllama($prompt);
    
    // Return the generated email
    echo json_encode([
        'email' => $generatedEmail
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'error' => $e->getMessage()
    ]);
}

function generateNewEmailPrompt($recipient, $subject, $keyPoints, $tone, $length) {
    $toneDescriptions = [
        'professional' => 'professional and business-appropriate',
        'friendly' => 'friendly and approachable',
        'formal' => 'very formal and respectful',
        'casual' => 'casual and conversational',
        'persuasive' => 'persuasive and compelling'
    ];
    
    $lengthInstructions = [
        'short' => 'Keep the email very concise, no more than 3-4 sentences.',
        'medium' => 'The email should be of medium length, about 1-2 paragraphs.',
        'long' => 'The email can be more detailed, up to 3-4 paragraphs if needed.'
    ];
    
    return "Compose a {$toneDescriptions[$tone]} email with the following details:
- Recipient: $recipient
- Subject: $subject
- Key points to include: $keyPoints

{$lengthInstructions[$length]} 
Format the email properly with appropriate greeting and closing. 
Ensure the tone is consistently {$toneDescriptions[$tone]} throughout.";
}

function generateReplyPrompt($originalEmail, $keyPoints, $tone) {
    $toneDescriptions = [
        'professional' => 'professional and business-appropriate',
        'friendly' => 'friendly and approachable',
        'formal' => 'very formal and respectful',
        'casual' => 'casual and conversational',
        'conciliatory' => 'understanding and seeking resolution'
    ];
    
    return "Compose a {$toneDescriptions[$tone]} email reply that addresses the following original email:
---
$originalEmail
---

Key points to include in your reply:
$keyPoints

Format the reply properly with appropriate greeting and closing. 
Maintain a {$toneDescriptions[$tone]} tone throughout and ensure you address all points from the original email.";
}

function callOllama($prompt) {
    // Ollama API endpoint (adjust according to your setup)
    $ollamaUrl = 'http://localhost:11434/api/generate'; // Default Ollama URL
    
    $data = [
        'model' => 'llama3', // or any other model you have
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.7,
            'max_tokens' => 1500
        ]
    ];
    
    $ch = curl_init($ollamaUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        throw new Exception('Ollama API error: ' . curl_error($ch));
    }
    
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($httpCode !== 200) {
        throw new Exception('Ollama API returned HTTP code ' . $httpCode);
    }
    
    curl_close($ch);
    
    $responseData = json_decode($response, true);
    
    if (!isset($responseData['response'])) {
        throw new Exception('Invalid response from Ollama API');
    }
    
    // Clean up the response
    $email = trim($responseData['response']);
    
    // Remove any extra quotes or formatting artifacts
    $email = preg_replace('/^"(.*)"$/', '$1', $email);
    
    return $email;
}
?>