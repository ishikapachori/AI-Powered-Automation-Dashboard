<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['message'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid input data']);
    exit;
}

$userMessage = trim($data['message']);

// Ollama API endpoint (assuming it's running locally)
$ollamaUrl = 'http://localhost:11434/api/generate';

// Your system prompt (from when the bot was built)
$systemPrompt = "You are a helpful AI assistant. Respond to the user in a friendly and professional manner.";

$payload = [
    'model' => 'llama3', // or whichever model you're using
    'prompt' => $userMessage,
    'system' => $systemPrompt,
    'stream' => false
];

$ch = curl_init($ollamaUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    echo json_encode(['success' => false, 'error' => 'Failed to get response from AI model']);
    exit;
}

$responseData = json_decode($response, true);

echo json_encode([
    'success' => true,
    'response' => $responseData['response'] ?? 'I apologize, but I cannot generate a response at this time.'
]);
?>