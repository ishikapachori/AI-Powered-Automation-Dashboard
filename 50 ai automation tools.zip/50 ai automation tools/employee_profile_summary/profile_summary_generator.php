<?php
header('Content-Type: application/json');

// Get the JSON data from the request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input data
if (!$data || 
    empty($data['fullName']) || 
    empty($data['position']) || 
    empty($data['department']) || 
    empty($data['tenure']) || 
    empty($data['skills']) || 
    empty($data['achievements'])) {
    
    echo json_encode(['error' => 'All required fields must be provided']);
    exit;
}

// Prepare the prompt for LLaMA/Ollama
$prompt = "Create a concise, professional one-paragraph summary (100-150 words) for an internal employee profile based on these details:
- Full Name: {$data['fullName']}
- Position: {$data['position']}
- Department: {$data['department']}
- Tenure: {$data['tenure']}
- Key Skills: {$data['skills']}
- Notable Achievements: {$data['achievements']}
" . (!empty($data['personality']) ? "- Personality/Work Style: {$data['personality']}\n" : "") . "

The summary should:
1. Begin with the employee's name and position
2. Highlight their key skills and expertise
3. Mention significant achievements
4. Include work style/personality if provided
5. Maintain a professional tone suitable for internal company use
6. Be exactly one paragraph, no bullet points or section headers";

// Call Ollama API
$ollamaResponse = callOllamaAPI($prompt);

if ($ollamaResponse === false) {
    echo json_encode(['error' => 'Failed to generate profile summary. Please try again.']);
    exit;
}

// Clean up and format the response
$summary = trim($ollamaResponse);
$summary = preg_replace('/\n+/', ' ', $summary); // Remove any newlines to ensure single paragraph

// Return the generated summary
echo json_encode(['summary' => $summary]);

function callOllamaAPI($prompt) {
    // Adjust this URL to your Ollama server endpoint
    $ollamaUrl = 'http://localhost:11434/api/generate';
    
    // Prepare the data for Ollama
    $ollamaData = [
        'model' => 'llama3', // or any other model you're using
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'temperature' => 0.6,
            'max_tokens' => 300,
            'top_p' => 0.9
        ]
    ];
    
    // Initialize cURL
    $ch = curl_init($ollamaUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($ollamaData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    // Execute the request
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        error_log('Ollama API error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }
    
    curl_close($ch);
    
    // Parse the response
    $responseData = json_decode($response, true);
    
    if (isset($responseData['response'])) {
        return trim($responseData['response']);
    } else {
        error_log('Ollama API unexpected response: ' . $response);
        return false;
    }
}
?>