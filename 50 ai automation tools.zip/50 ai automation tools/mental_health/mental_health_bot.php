<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get the request body
$requestData = json_decode(file_get_contents('php://input'), true);

if (!isset($requestData['message'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'No message provided'
    ]);
    exit;
}

$userMessage = $requestData['message'];

// Ollama API endpoint
$ollamaEndpoint = 'http://localhost:11434/api/generate';

// Prepare the system prompt for mental health assistant
$systemPrompt = "You are a friendly and supportive Mental Health Assistant designed to provide non-medical emotional support, motivation, and general well-being suggestions. 

Important guidelines:
1. Always respond with empathy and compassion
2. Never provide medical advice or diagnoses
3. Suggest healthy coping mechanisms and self-care practices
4. Encourage seeking professional help for serious concerns
5. Keep responses positive and motivational
6. Provide practical, actionable suggestions when appropriate
7. Maintain a warm, friendly tone

If someone appears to be in crisis, gently suggest they contact a mental health professional or crisis hotline.";

// Prepare the prompt for Ollama
$prompt = $systemPrompt . "\n\nUser: " . $userMessage . "\n\nAssistant:";

// Prepare the request data
$requestBody = json_encode([
    'model' => 'llama3', // Use the appropriate model name configured in Ollama
    'prompt' => $prompt,
    'stream' => false,
    'temperature' => 0.7,
    'max_tokens' => 500
]);

// Initialize cURL session
$ch = curl_init($ollamaEndpoint);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Execute the request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to connect to Ollama: ' . curl_error($ch)
    ]);
    curl_close($ch);
    exit;
}

curl_close($ch);

// Process the response
$responseData = json_decode($response, true);

if (!$responseData || !isset($responseData['response'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid response from Ollama'
    ]);
    exit;
}

// Get the bot's response
$botResponse = $responseData['response'];

// Generate contextual suggestions based on user message
$suggestions = generateSuggestions($userMessage);

// Return the response
echo json_encode([
    'status' => 'success',
    'response' => $botResponse,
    'suggestions' => $suggestions
]);

/**
 * Generate contextual suggestions based on user message
 * 
 * @param string $message User message
 * @return array Array of suggestions
 */
function generateSuggestions($message) {
    $message = strtolower($message);
    
    // Default suggestions
    $defaultSuggestions = [
        "How can I practice self-care?",
        "I need motivation",
        "Breathing exercises",
        "How to stay positive?"
    ];
    
    // Anxiety related suggestions
    if (strpos($message, 'anxious') !== false || strpos($message, 'anxiety') !== false || 
        strpos($message, 'nervous') !== false || strpos($message, 'worry') !== false) {
        return [
            "Breathing techniques for anxiety",
            "How to ground myself",
            "Quick anxiety relief tips",
            "Calming activities"
        ];
    }
    
    // Depression related suggestions
    if (strpos($message, 'sad') !== false || strpos($message, 'depress') !== false || 
        strpos($message, 'down') !== false || strpos($message, 'unhappy') !== false) {
        return [
            "Small steps to feel better",
            "Self-care activities",
            "How to find motivation",
            "Positive affirmations"
        ];
    }
    
    // Stress related suggestions
    if (strpos($message, 'stress') !== false || strpos($message, 'overwhelm') !== false || 
        strpos($message, 'pressure') !== false) {
        return [
            "Stress management techniques",
            "How to prioritize tasks",
            "Quick relaxation methods",
            "Mindfulness practices"
        ];
    }
    
    // Sleep related suggestions
    if (strpos($message, 'sleep') !== false || strpos($message, 'insomnia') !== false || 
        strpos($message, 'tired') !== false) {
        return [
            "Better sleep habits",
            "Bedtime routine ideas",
            "Relaxation before sleep",
            "Managing racing thoughts"
        ];
    }
    
    // Return default suggestions if no specific category is matched
    return $defaultSuggestions;
}
?>
