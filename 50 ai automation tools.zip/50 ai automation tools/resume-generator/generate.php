<?php
// generate.php - Backend for Resume & Cover Letter Generator

// Set headers for JSON response
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get form data
$documentType = $_POST['document-type'] ?? '';
$fullName = $_POST['full-name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$skills = $_POST['skills'] ?? '';
$experience = $_POST['experience'] ?? '';
$education = $_POST['education'] ?? '';
$jobDescription = $_POST['job-description'] ?? '';

// Validate required fields
if (empty($documentType) || empty($fullName) || empty($email) || empty($skills)) {
    echo json_encode([
        'success' => false,
        'message' => 'Please fill all required fields'
    ]);
    exit;
}

// Initialize Ollama client
require_once 'OllamaClient.php';
$ollama = new OllamaClient('http://localhost:11434');

// Prepare prompt based on document type
if ($documentType === 'resume') {
    $prompt = "Generate a professional resume in plain text format for $fullName with the following information:
    
Email: $email
Phone: $phone
Skills: $skills
Work Experience: $experience
Education: $education

The resume should be well-structured, concise, and highlight the most relevant skills and experiences. Format it in a clean, professional way that's easy to read.";
} else {
    $prompt = "Generate a professional cover letter in plain text format for $fullName applying for the following job:
    
$jobDescription

Include the following information:
Email: $email
Phone: $phone
Skills: $skills
Work Experience: $experience
Education: $education

The cover letter should be personalized, highlight relevant skills and experiences, and explain why $fullName is a good fit for this position. Keep it concise, professional, and persuasive.";
}

try {
    // Generate content using Ollama
    $response = $ollama->generate('llama3', $prompt);
    
    echo json_encode([
        'success' => true,
        'content' => $response
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error generating content: ' . $e->getMessage()
    ]);
}
