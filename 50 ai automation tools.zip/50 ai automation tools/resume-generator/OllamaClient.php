<?php
// OllamaClient.php - Client for interacting with Ollama API

class OllamaClient {
    private $baseUrl;
    
    /**
     * Constructor
     * 
     * @param string $baseUrl The base URL for the Ollama API
     */
    public function __construct($baseUrl) {
        $this->baseUrl = rtrim($baseUrl, '/');
    }
    
    /**
     * Generate text using the specified model
     * 
     * @param string $model The model to use (e.g., 'llama3')
     * @param string $prompt The prompt to send to the model
     * @param array $options Additional options for the generation
     * @return string The generated text
     * @throws Exception If the API request fails
     */
    public function generate($model, $prompt, $options = []) {
        $url = $this->baseUrl . '/api/generate';
        
        $data = array_merge([
            'model' => $model,
            'prompt' => $prompt,
            'stream' => false
        ], $options);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception('Curl error: ' . curl_error($ch));
        }
        
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception('API request failed with status code ' . $httpCode . ': ' . $response);
        }
        
        $responseData = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON response: ' . json_last_error_msg());
        }
        
        return $responseData['response'] ?? '';
    }
}
